# Zadání do EDISONu

## Čeština

### Název ZP

Vizualizace částicové dynamiky v Hamakerově modelu interakce

### Zásady pro vypracování

Cílem práce je navrhnout a implementovat prototyp softwarového nástroje pro interaktivní 3D vizualizaci částicové dynamiky v konečném periodickém boxu. Fyzikální motivací je agregace nanočástic při řízené vakuové lyofilizaci a Hamakerův model interakce. Hlavní těžiště práce je však v návrhu softwarové architektury, reprezentaci částicového systému, základním časovém vývoji a 3D vizualizaci.

[ol][li]Seznamte se s aplikační motivací částicové dynamiky při řízené vakuové lyofilizaci a s významem Hamakerovy interakce jako jednoho z možných silových modelů.[/li][li]Navrhněte architekturu aplikace oddělující výpočetní backend, přenos dat a vizualizační frontend.[/li][li]Navrhněte datový model částic, výpočetní domény a stavů simulace tak, aby byl později rozšiřitelný o další síly, okrajové podmínky a agregační pravidla.[/li][li]Zvolte a zdůvodněte jednoduchý numerický způsob časového vývoje částic a práci s periodickým boxem.[/li][li]Stručně porovnejte vhodné technologie pro GUI a 3D vizualizaci a vyberte řešení odpovídající rozsahu práce.[/li][li]Implementujte interaktivní prototyp umožňující spouštění, zastavení a reset výpočtu, změnu základních parametrů a plynulé zobrazení částic ve 3D scéně.[/li][li]Připravte základní testovací a demonstrační scénáře pro ověření funkčnosti backendu a použitelnosti vizualizace.[/li][li]Zhodnoťte omezení vytvořeného prototypu a navrhněte další kroky směrem k přesnějšímu fyzikálnímu modelu a analýze agregace.[/li][/ol]

### Seznam doporučené odborné literatury

[ol][li]NEZBEDA, I., KOLAFA, J., KOTRLA, M. [i]Úvod do počítačových simulací: metody Monte Carlo a molekulární dynamiky[/i]. Praha: Karolinum, 2003. ISBN 80-246-0649-6.[/li][li]ALLEN, M. P., TILDESLEY, D. J. [i]Computer Simulation of Liquids[/i]. 2nd ed. Oxford: Oxford University Press, 2017. ISBN 978-0-19-880319-5.[/li][li]FRENKEL, D., SMIT, B. [i]Understanding Molecular Simulation: From Algorithms to Applications[/i]. 2nd ed. San Diego: Academic Press, 2002. ISBN 978-0-12-267351-1.[/li][li]RAPAPORT, D. C. [i]The Art of Molecular Dynamics Simulation[/i]. 2nd ed. Cambridge: Cambridge University Press, 2004. ISBN 978-0-521-82568-9.[/li][li]HAMAKER, H. C. The London-van der Waals attraction between spherical particles. [i]Physica[/i]. 1937, 4(10), 1058-1072. DOI 10.1016/S0031-8914(37)80203-7.[/li][li]DVORSKÝ, R. Preparation of high-performance photocatalytic core-shell lamellar nanostructures ZnO-(Si)-ZnO with high specific surface area. [i]Advanced Materials Letters[/i]. 2016, 7(9), 730-734. DOI 10.5185/amlett.2016.6380.[/li][li]KRPELÍK, D., DVORSKÝ, R., MANČÍK, P., BEDNÁŘ, J., SVOBODA, L. Mathematical modelling of lamellar aggregation of dispersed globular nanoparticles nC60 on the interface upon sublimation of water molecules from rapid frozen dispersion. [i]Journal of Nanoscience and Nanotechnology[/i]. 2019, 19(5), 2671-2677. DOI 10.1166/jnn.2019.15856.[/li][li]LENGYEL, E. [i]Mathematics for 3D Game Programming and Computer Graphics[/i]. 3rd ed. Boston: Cengage Learning, 2012. ISBN 978-1-4354-5886-4.[/li][/ol]

### Poznámka

Práce je zaměřena především na softwarový návrh a implementaci vizualizačního prototypu. Přesnější fyzikální model, pokročilé řešení kolizí a výkonové optimalizace lze chápat jako možná rozšíření podle průběhu práce.

## Angličtina

### Název ZP

Visualization of Particle Dynamics in the Hamaker Interaction Model

### Zásady pro vypracování

The aim of the thesis is to design and implement a prototype software tool for interactive 3D visualization of particle dynamics in a finite periodic box. The physical motivation is nanoparticle aggregation during controlled vacuum freeze-drying and the Hamaker interaction model. The main focus of the thesis is nevertheless the software architecture, representation of the particle system, basic time evolution and 3D visualization.

[ol][li]Study the application motivation of particle dynamics in controlled vacuum freeze-drying and the role of the Hamaker interaction as one possible force model.[/li][li]Design an application architecture separating the computational backend, data transfer and visualization frontend.[/li][li]Design a data model for particles, the computational domain and simulation states so that it can later be extended with additional forces, boundary conditions and aggregation rules.[/li][li]Choose and justify a simple numerical method for particle time evolution and handling of the periodic box.[/li][li]Briefly compare suitable technologies for GUI and 3D visualization and select a solution appropriate for the scope of the thesis.[/li][li]Implement an interactive prototype allowing start, stop and reset of the computation, modification of basic parameters and smooth display of particles in a 3D scene.[/li][li]Prepare basic test and demonstration scenarios to verify backend functionality and usability of the visualization.[/li][li]Evaluate the limitations of the prototype and propose further steps towards a more accurate physical model and aggregation analysis.[/li][/ol]

### Seznam doporučené odborné literatury

[ol][li]NEZBEDA, I., KOLAFA, J., KOTRLA, M. [i]Úvod do počítačových simulací: metody Monte Carlo a molekulární dynamiky[/i]. Praha: Karolinum, 2003. ISBN 80-246-0649-6.[/li][li]ALLEN, M. P., TILDESLEY, D. J. [i]Computer Simulation of Liquids[/i]. 2nd ed. Oxford: Oxford University Press, 2017. ISBN 978-0-19-880319-5.[/li][li]FRENKEL, D., SMIT, B. [i]Understanding Molecular Simulation: From Algorithms to Applications[/i]. 2nd ed. San Diego: Academic Press, 2002. ISBN 978-0-12-267351-1.[/li][li]RAPAPORT, D. C. [i]The Art of Molecular Dynamics Simulation[/i]. 2nd ed. Cambridge: Cambridge University Press, 2004. ISBN 978-0-521-82568-9.[/li][li]HAMAKER, H. C. The London-van der Waals attraction between spherical particles. [i]Physica[/i]. 1937, 4(10), 1058-1072. DOI 10.1016/S0031-8914(37)80203-7.[/li][li]DVORSKÝ, R. Preparation of high-performance photocatalytic core-shell lamellar nanostructures ZnO-(Si)-ZnO with high specific surface area. [i]Advanced Materials Letters[/i]. 2016, 7(9), 730-734. DOI 10.5185/amlett.2016.6380.[/li][li]KRPELÍK, D., DVORSKÝ, R., MANČÍK, P., BEDNÁŘ, J., SVOBODA, L. Mathematical modelling of lamellar aggregation of dispersed globular nanoparticles nC60 on the interface upon sublimation of water molecules from rapid frozen dispersion. [i]Journal of Nanoscience and Nanotechnology[/i]. 2019, 19(5), 2671-2677. DOI 10.1166/jnn.2019.15856.[/li][li]LENGYEL, E. [i]Mathematics for 3D Game Programming and Computer Graphics[/i]. 3rd ed. Boston: Cengage Learning, 2012. ISBN 978-1-4354-5886-4.[/li][/ol]

### Poznámka

The thesis is primarily focused on software design and implementation of a visualization prototype. A more accurate physical model, advanced collision handling and performance optimizations may be treated as possible extensions depending on the progress of the work.
