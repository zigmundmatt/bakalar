#include "simulation.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <vector>

namespace
{
constexpr int kMinParticleCount = 1;
constexpr int kMaxParticleCount = 20000;
constexpr Real kMinBoxSize = Real{1};
constexpr Real kMaxBoxSize = Real{400};
constexpr Real kMinMedianRadiusUm = Real{0.005};
constexpr Real kMaxMedianRadiusUm = Real{2};
constexpr Real kMinLogSigma = Real{0.01};
constexpr Real kMaxLogSigma = Real{1.5};
constexpr Real kMinPairForceScale = Real{0};
constexpr Real kMaxPairForceScale = Real{0.1};
constexpr Real kMinPairRegularizationLength = Real{0.001};
constexpr Real kMaxPairRegularizationLength = Real{2};
constexpr Real kMinPairCutoffGap = Real{0.005};
constexpr Real kMaxPairCutoffGap = Real{20};
constexpr Real kMinPairDamping = Real{0};
constexpr Real kMaxPairDamping = Real{2};
constexpr int kMinOverlapCorrectionIterations = 1;
constexpr int kMaxOverlapCorrectionIterations = 16;
constexpr Real kMinOverlapCorrectionFraction = Real{0.05};
constexpr Real kMaxOverlapCorrectionFraction = Real{0.95};
constexpr int kMaxPairCellsPerAxis = 64;

Real clampBoxSize(Real value)
{
    return std::clamp(value, kMinBoxSize, kMaxBoxSize);
}

Real wrapPeriodic(Real value, Real size)
{
    const Real half = size * Real{0.5};
    while (value >= half)
    {
        value -= size;
    }
    while (value < -half)
    {
        value += size;
    }
    return value;
}

int positiveModulo(int value, int modulus)
{
    const int remainder = value % modulus;
    return remainder < 0 ? remainder + modulus : remainder;
}

template <typename Function>
void runSequential(std::size_t count, Function&& function)
{
    for (std::size_t i = 0; i < count; ++i)
    {
        function(i);
    }
}
}

std::size_t ParticleStore::size() const
{
    return id.size();
}

void ParticleStore::clear()
{
    id.clear();
    x.clear();
    y.clear();
    z.clear();
    vx.clear();
    vy.clear();
    vz.clear();
    fx.clear();
    fy.clear();
    fz.clear();
    radius.clear();
    mass.clear();
    type.clear();
}

void ParticleStore::reserve(std::size_t count)
{
    id.reserve(count);
    x.reserve(count);
    y.reserve(count);
    z.reserve(count);
    vx.reserve(count);
    vy.reserve(count);
    vz.reserve(count);
    fx.reserve(count);
    fy.reserve(count);
    fz.reserve(count);
    radius.reserve(count);
    mass.reserve(count);
    type.reserve(count);
}

void ParticleStore::eraseSwap(std::size_t index)
{
    const std::size_t last = size() - 1;
    if (index != last)
    {
        id[index] = id[last];
        x[index] = x[last];
        y[index] = y[last];
        z[index] = z[last];
        vx[index] = vx[last];
        vy[index] = vy[last];
        vz[index] = vz[last];
        fx[index] = fx[last];
        fy[index] = fy[last];
        fz[index] = fz[last];
        radius[index] = radius[last];
        mass[index] = mass[last];
        type[index] = type[last];
    }

    id.pop_back();
    x.pop_back();
    y.pop_back();
    z.pop_back();
    vx.pop_back();
    vy.pop_back();
    vz.pop_back();
    fx.pop_back();
    fy.pop_back();
    fz.pop_back();
    radius.pop_back();
    mass.pop_back();
    type.pop_back();
}

Simulation::Simulation(std::uint32_t seed)
    : rng_(seed)
{
    startWorkers();
    reset(256);
}

Simulation::~Simulation()
{
    for (std::jthread& worker : workers_)
    {
        worker.request_stop();
    }
    workerCv_.notify_all();
}

void Simulation::reset(int particleCount)
{
    particles_.clear();
    particles_.reserve(static_cast<std::size_t>(std::clamp(particleCount, kMinParticleCount, kMaxParticleCount)));
    nextId_ = 1;
    simulationTime_ = 0.0;
    integrationSteps_ = 0;
    addParticles(particleCount);
}

void Simulation::step(Real dt)
{
    currentStepThreads_ = 1;
    lastStepItems_ = particles_.size();

    if (!config_.running)
    {
        lastStepThreads_ = 0;
        return;
    }

    const Real substepDt = dt * config_.timeScale / static_cast<Real>(kPhysicsSubsteps);
    for (int substep = 0; substep < kPhysicsSubsteps; ++substep)
    {
        clearForces();
        applyForces();
        integrate(substepDt);
        if (config_.collisions.enabled)
        {
            resolveImpulseCollisions();
        }
        if (config_.forces.pairInteractionEnabled && config_.forces.overlapCorrectionEnabled)
        {
            resolveOverlaps();
        }
        simulationTime_ += static_cast<double>(substepDt);
        ++integrationSteps_;
    }
    lastStepThreads_ = currentStepThreads_;
}

void Simulation::apply(const AddParticlesCommand& command)
{
    addParticles(command.count);
}

void Simulation::apply(const RemoveParticlesCommand& command)
{
    removeParticles(command.count);
}

void Simulation::apply(const SetRunningCommand& command)
{
    config_.running = command.running;
}

void Simulation::apply(const SetParticleCountCommand& command)
{
    const int target = std::clamp(command.count, kMinParticleCount, kMaxParticleCount);
    const int current = particleCount();
    if (target > current)
    {
        addParticles(target - current);
    }
    else if (target < current)
    {
        removeParticles(current - target);
    }
}

void Simulation::apply(const SetTimeScaleCommand& command)
{
    config_.timeScale = std::clamp(command.timeScale, Real{0}, Real{5});
}

void Simulation::apply(const SetBoxCommand& command)
{
    config_.box.size.x = clampBoxSize(command.box.size.x);
    config_.box.size.y = clampBoxSize(command.box.size.y);
    config_.box.size.z = clampBoxSize(command.box.size.z);

    for (std::size_t i = 0; i < particles_.size(); ++i)
    {
        wrapPosition(i);
    }
}

void Simulation::apply(const RegenerateParticlesCommand&)
{
    reset(particleCount());
}

void Simulation::apply(const ConfigureTwoParticleTestCommand& command)
{
    configureTwoParticleTest(command.surfaceGap);
}

void Simulation::apply(const SetRadiusDistributionCommand& command)
{
    config_.radiusDistribution.medianRadiusUm = std::clamp(
        command.distribution.medianRadiusUm, kMinMedianRadiusUm, kMaxMedianRadiusUm);
    config_.radiusDistribution.logSigma = std::clamp(
        command.distribution.logSigma, kMinLogSigma, kMaxLogSigma);
    reset(particleCount());
}

void Simulation::apply(const SetDampingEnabledCommand& command)
{
    config_.forces.dampingEnabled = command.enabled;
}

void Simulation::apply(const SetConstantFieldEnabledCommand& command)
{
    config_.forces.constantFieldEnabled = command.enabled;
}

void Simulation::apply(const SetPairInteractionEnabledCommand& command)
{
    config_.forces.pairInteractionEnabled = command.enabled;
}

void Simulation::apply(const SetPairInteractionParamsCommand& command)
{
    config_.forces.pairForceScale = std::clamp(command.forceScale, kMinPairForceScale, kMaxPairForceScale);
    config_.forces.pairRegularizationLength = std::clamp(
        command.regularizationLength, kMinPairRegularizationLength, kMaxPairRegularizationLength);
    config_.forces.pairCutoffGap = std::clamp(command.cutoffGap, kMinPairCutoffGap, kMaxPairCutoffGap);
    config_.forces.pairDamping = std::clamp(command.damping, kMinPairDamping, kMaxPairDamping);
    config_.forces.overlapCorrectionIterations = std::clamp(
        command.overlapCorrectionIterations, kMinOverlapCorrectionIterations, kMaxOverlapCorrectionIterations);
    config_.forces.overlapCorrectionFraction = std::clamp(
        command.overlapCorrectionFraction, kMinOverlapCorrectionFraction, kMaxOverlapCorrectionFraction);
}

void Simulation::apply(const SetOverlapCorrectionEnabledCommand& command)
{
    config_.forces.overlapCorrectionEnabled = command.enabled;
}

void Simulation::apply(const SetContactModelCommand& command)
{
    config_.forces.contactModel = command.model;
}

void Simulation::apply(const SetCollisionsEnabledCommand& command)
{
    config_.collisions.enabled = command.enabled;
}

void Simulation::apply(const SetRestitutionCommand& command)
{
    config_.collisions.restitution = std::clamp(command.restitution, Real{0}, Real{1});
}

int Simulation::particleCount() const
{
    return static_cast<int>(particles_.size());
}

SimulationSnapshot Simulation::snapshot() const
{
    return SimulationSnapshot{config_, &particles_, simulationTime_, integrationSteps_};
}

ParallelStats Simulation::parallelStats() const
{
    return ParallelStats{
        .enabled = PARTICLE_ENABLE_PARALLEL != 0,
        .hardwareThreads = std::max(1U, std::thread::hardware_concurrency()),
        .configuredWorkers = workerCount_,
        .lastStepThreads = lastStepThreads_,
        .lastStepItems = lastStepItems_,
        .minItems = PARTICLE_PARALLEL_MIN_ITEMS
    };
}

void Simulation::addParticles(int count)
{
    const int available = kMaxParticleCount - particleCount();
    count = std::clamp(count, 0, available);
    if (count <= 0)
    {
        return;
    }

    std::uniform_real_distribution<Real> unit(Real{-0.5}, Real{0.5});
    std::lognormal_distribution<Real> radius(
        std::log(config_.radiusDistribution.medianRadiusUm),
        config_.radiusDistribution.logSigma);
    std::uniform_int_distribution<int> type(0, 5);

    particles_.reserve(particles_.size() + static_cast<std::size_t>(count));
    for (int i = 0; i < count; ++i)
    {
        const Real particleRadius = std::min(radius(rng_), std::min({
            config_.box.size.x, config_.box.size.y, config_.box.size.z
        }) * Real{0.08});

        particles_.id.push_back(nextId_++);
        particles_.x.push_back(unit(rng_) * config_.box.size.x);
        particles_.y.push_back(unit(rng_) * config_.box.size.y);
        particles_.z.push_back(unit(rng_) * config_.box.size.z);
        particles_.vx.push_back(Real{0});
        particles_.vy.push_back(Real{0});
        particles_.vz.push_back(Real{0});
        particles_.fx.push_back(Real{0});
        particles_.fy.push_back(Real{0});
        particles_.fz.push_back(Real{0});
        particles_.radius.push_back(particleRadius);
        particles_.mass.push_back(std::max(Real{0.01}, particleRadius * particleRadius * particleRadius));
        particles_.type.push_back(static_cast<std::uint16_t>(type(rng_)));
    }
}

void Simulation::addParticle(Vec3 position, Real radius, std::uint16_t type)
{
    const Real clampedRadius = std::clamp(radius, kMinMedianRadiusUm, std::min({
        config_.box.size.x,
        config_.box.size.y,
        config_.box.size.z
    }) * Real{0.08});
    particles_.id.push_back(nextId_++);
    particles_.x.push_back(position.x);
    particles_.y.push_back(position.y);
    particles_.z.push_back(position.z);
    particles_.vx.push_back(Real{0});
    particles_.vy.push_back(Real{0});
    particles_.vz.push_back(Real{0});
    particles_.fx.push_back(Real{0});
    particles_.fy.push_back(Real{0});
    particles_.fz.push_back(Real{0});
    particles_.radius.push_back(clampedRadius);
    particles_.mass.push_back(std::max(Real{0.01}, clampedRadius * clampedRadius * clampedRadius));
    particles_.type.push_back(type);
}

void Simulation::configureTwoParticleTest(Real surfaceGap)
{
    config_.running = false;
    config_.forces.dampingEnabled = false;
    config_.forces.constantFieldEnabled = false;
    config_.forces.pairInteractionEnabled = true;
    config_.collisions.enabled = false;

    particles_.clear();
    particles_.reserve(2);
    nextId_ = 1;
    simulationTime_ = 0.0;
    integrationSteps_ = 0;

    const Real radius = std::clamp(config_.radiusDistribution.medianRadiusUm, Real{0.05}, Real{0.5});
    const Real maxGap = std::min({
        config_.box.size.x,
        config_.box.size.y,
        config_.box.size.z
    }) * Real{0.8};
    const Real gap = std::clamp(surfaceGap, Real{0}, maxGap);
    const Real centerDistance = radius * Real{2} + gap;
    addParticle(Vec3{-centerDistance * Real{0.5}, Real{0}, Real{0}}, radius, 0);
    addParticle(Vec3{centerDistance * Real{0.5}, Real{0}, Real{0}}, radius, 1);
}

void Simulation::removeParticles(int count)
{
    count = std::clamp(count, 0, std::max(0, particleCount() - kMinParticleCount));
    for (int i = 0; i < count; ++i)
    {
        particles_.eraseSwap(particles_.size() - 1);
    }
}

void Simulation::startWorkers()
{
#if PARTICLE_ENABLE_PARALLEL
    if (workerCount_ <= 1)
    {
        return;
    }

    workers_.reserve(workerCount_ - 1);
    for (std::size_t workerIndex = 1; workerIndex < workerCount_; ++workerIndex)
    {
        workers_.emplace_back([this, workerIndex](std::stop_token stopToken) {
            workerLoop(stopToken, workerIndex);
        });
    }
#endif
}

void Simulation::workerLoop(std::stop_token stopToken, std::size_t workerIndex)
{
    std::uint64_t observedGeneration = 0;
    std::unique_lock lock(workerMutex_);

    while (!stopToken.stop_requested())
    {
        workerCv_.wait(lock, stopToken, [this, observedGeneration] {
            return workerGeneration_ != observedGeneration;
        });

        if (stopToken.stop_requested())
        {
            break;
        }

        observedGeneration = workerGeneration_;
        if (workerIndex >= workerTaskThreads_)
        {
            continue;
        }

        const std::size_t begin = workerIndex * workerBlockSize_;
        const std::size_t end = std::min(workerTaskItems_, begin + workerBlockSize_);
        const std::function<void(std::size_t, std::size_t)> task = workerTask_;

        lock.unlock();
        for (std::size_t i = begin; i < end; ++i)
        {
            task(workerIndex, i);
        }
        lock.lock();

        if (remainingWorkers_ > 0)
        {
            --remainingWorkers_;
        }
        if (remainingWorkers_ == 0)
        {
            workerDoneCv_.notify_one();
        }
    }
}

template <typename Function>
void Simulation::parallelFor(std::size_t count, Function&& function)
{
    parallelForIndexed(count, [function = std::forward<Function>(function)](std::size_t, std::size_t i) mutable {
        function(i);
    });
}

template <typename Function>
void Simulation::parallelForIndexed(std::size_t count, Function&& function)
{
#if PARTICLE_ENABLE_PARALLEL
    if (count < PARTICLE_PARALLEL_MIN_ITEMS || workerCount_ <= 1 || workers_.empty())
    {
        currentStepThreads_ = std::max(currentStepThreads_, 1U);
        for (std::size_t i = 0; i < count; ++i)
        {
            function(0, i);
        }
        return;
    }

    const std::size_t threadCount = std::min<std::size_t>(workerCount_, count);
    currentStepThreads_ = std::max<unsigned int>(currentStepThreads_, static_cast<unsigned int>(threadCount));
    const std::size_t blockSize = (count + threadCount - 1) / threadCount;
    {
        std::lock_guard lock(workerMutex_);
        workerTask_ = std::forward<Function>(function);
        workerTaskItems_ = count;
        workerBlockSize_ = blockSize;
        workerTaskThreads_ = threadCount;
        remainingWorkers_ = threadCount - 1;
        ++workerGeneration_;
    }
    workerCv_.notify_all();

    const std::size_t mainEnd = std::min(count, blockSize);
    for (std::size_t i = 0; i < mainEnd; ++i)
    {
        workerTask_(0, i);
    }

    std::unique_lock lock(workerMutex_);
    workerDoneCv_.wait(lock, [this] {
        return remainingWorkers_ == 0;
    });
    workerTask_ = {};
#else
    currentStepThreads_ = std::max(currentStepThreads_, 1U);
    for (std::size_t i = 0; i < count; ++i)
    {
        function(0, i);
    }
#endif
}

void Simulation::clearForces()
{
    parallelFor(particles_.size(), [this](std::size_t i) {
        particles_.fx[i] = Real{0};
        particles_.fy[i] = Real{0};
        particles_.fz[i] = Real{0};
    });
}

void Simulation::applyForces()
{
    parallelFor(particles_.size(), [this](std::size_t i) {
        if (config_.forces.constantFieldEnabled)
        {
            particles_.fx[i] += particles_.mass[i] * config_.forces.constantAcceleration.x;
            particles_.fy[i] += particles_.mass[i] * config_.forces.constantAcceleration.y;
            particles_.fz[i] += particles_.mass[i] * config_.forces.constantAcceleration.z;
        }

        if (config_.forces.dampingEnabled)
        {
            particles_.fx[i] -= config_.forces.damping * particles_.vx[i];
            particles_.fy[i] -= config_.forces.damping * particles_.vy[i];
            particles_.fz[i] -= config_.forces.damping * particles_.vz[i];
        }
    });

    if (config_.forces.pairInteractionEnabled)
    {
        applyPairInteractionForces();
    }
}

void Simulation::applyPairInteractionForces()
{
    const std::size_t count = particles_.size();
    if (count < 2)
    {
        return;
    }

    const Real maxRadius = *std::max_element(particles_.radius.begin(), particles_.radius.end());
    const Real cutoffGap = config_.forces.pairCutoffGap;
    const Real interactionDistance = std::max(Real{0.001}, maxRadius * Real{2} + cutoffGap);
    const std::array<Real, 3> boxSize{
        config_.box.size.x,
        config_.box.size.y,
        config_.box.size.z
    };
    const std::array<int, 3> dims{
        std::clamp(static_cast<int>(std::floor(boxSize[0] / interactionDistance)), 1, kMaxPairCellsPerAxis),
        std::clamp(static_cast<int>(std::floor(boxSize[1] / interactionDistance)), 1, kMaxPairCellsPerAxis),
        std::clamp(static_cast<int>(std::floor(boxSize[2] / interactionDistance)), 1, kMaxPairCellsPerAxis)
    };
    const int cellCount = dims[0] * dims[1] * dims[2];
    std::vector<std::vector<std::size_t>> cells(static_cast<std::size_t>(cellCount));

    auto cellIndex = [dims](int ix, int iy, int iz) {
        ix = positiveModulo(ix, dims[0]);
        iy = positiveModulo(iy, dims[1]);
        iz = positiveModulo(iz, dims[2]);
        return (iz * dims[1] + iy) * dims[0] + ix;
    };
    auto particleCellCoord = [boxSize, dims](Real value, int axis) {
        const Real normalized = (value + boxSize[axis] * Real{0.5}) / boxSize[axis];
        return std::clamp(static_cast<int>(std::floor(normalized * static_cast<Real>(dims[axis]))), 0, dims[axis] - 1);
    };

    for (std::size_t i = 0; i < count; ++i)
    {
        const int ix = particleCellCoord(particles_.x[i], 0);
        const int iy = particleCellCoord(particles_.y[i], 1);
        const int iz = particleCellCoord(particles_.z[i], 2);
        cells[static_cast<std::size_t>(cellIndex(ix, iy, iz))].push_back(i);
    }

    const Real forceScale = config_.forces.pairForceScale;
    const Real ell = config_.forces.pairRegularizationLength;
    const Real ell3 = ell * ell * ell;
    const Real contactStiffness = forceScale / ell3;
    const Real damping = config_.forces.pairDamping;
    const Real distanceEpsilon = Real{1e-9};
    std::size_t pairThreadCount = 1;
#if PARTICLE_ENABLE_PARALLEL
    if (static_cast<std::size_t>(cellCount) >= PARTICLE_PARALLEL_MIN_ITEMS && workerCount_ > 1 && !workers_.empty())
    {
        pairThreadCount = std::min<std::size_t>(workerCount_, static_cast<std::size_t>(cellCount));
    }
#endif
    std::vector<std::vector<Real>> localFx(pairThreadCount, std::vector<Real>(count, Real{0}));
    std::vector<std::vector<Real>> localFy(pairThreadCount, std::vector<Real>(count, Real{0}));
    std::vector<std::vector<Real>> localFz(pairThreadCount, std::vector<Real>(count, Real{0}));

    parallelForIndexed(static_cast<std::size_t>(cellCount), [&](std::size_t threadIndex, std::size_t baseCellIndex) {
        const int baseCell = static_cast<int>(baseCellIndex);
        const auto& baseParticles = cells[baseCellIndex];
        if (baseParticles.empty())
        {
            return;
        }
        const int baseIz = baseCell / (dims[0] * dims[1]);
        const int baseRemainder = baseCell - baseIz * dims[0] * dims[1];
        const int baseIy = baseRemainder / dims[0];
        const int baseIx = baseRemainder - baseIy * dims[0];
        auto& fxBuffer = localFx[threadIndex];
        auto& fyBuffer = localFy[threadIndex];
        auto& fzBuffer = localFz[threadIndex];
        std::vector<int> visitedNeighborCells;
        visitedNeighborCells.reserve(27);

        for (int dz = -1; dz <= 1; ++dz)
        {
            for (int dy = -1; dy <= 1; ++dy)
            {
                for (int dx = -1; dx <= 1; ++dx)
                {
                    const int neighborCell = cellIndex(baseIx + dx, baseIy + dy, baseIz + dz);
                    if (neighborCell < baseCell)
                    {
                        continue;
                    }
                    if (std::ranges::find(visitedNeighborCells, neighborCell) != visitedNeighborCells.end())
                    {
                        continue;
                    }
                    visitedNeighborCells.push_back(neighborCell);
                    const auto& cellParticles = cells[static_cast<std::size_t>(neighborCell)];
                    for (const std::size_t i : baseParticles)
                    {
                        for (const std::size_t j : cellParticles)
                        {
                            if (neighborCell == baseCell && j <= i)
                            {
                                continue;
                            }

                            Real rx = wrapPeriodic(particles_.x[j] - particles_.x[i], config_.box.size.x);
                            Real ry = wrapPeriodic(particles_.y[j] - particles_.y[i], config_.box.size.y);
                            Real rz = wrapPeriodic(particles_.z[j] - particles_.z[i], config_.box.size.z);
                            Real distanceSquared = rx * rx + ry * ry + rz * rz;
                            const Real radiusSum = particles_.radius[i] + particles_.radius[j];
                            const Real pairCutoffDistance = radiusSum + cutoffGap;
                            if (distanceSquared > pairCutoffDistance * pairCutoffDistance)
                            {
                                continue;
                            }

                            Real distance = std::sqrt(distanceSquared);
                            if (distance < distanceEpsilon)
                            {
                                rx = Real{1};
                                ry = Real{0};
                                rz = Real{0};
                                distance = Real{1};
                            }

                            const Real invDistance = Real{1} / distance;
                            const Real nx = rx * invDistance;
                            const Real ny = ry * invDistance;
                            const Real nz = rz * invDistance;
                            const Real h = distance - radiusSum;
                            Real conservativeForceMagnitude = -forceScale * h * h / (h * h * h + ell3);
                            if (h < Real{0})
                            {
                                const Real overlap = -h;
                                switch (config_.forces.contactModel)
                                {
                                case ContactModel::Linear:
                                    conservativeForceMagnitude = contactStiffness * overlap;
                                    break;
                                case ContactModel::Hertz:
                                    conservativeForceMagnitude = contactStiffness * overlap * std::sqrt(overlap);
                                    break;
                                case ContactModel::Quadratic:
                                    conservativeForceMagnitude = contactStiffness * overlap * overlap;
                                    break;
                                }
                            }
                            const Real relativeNormalVelocity =
                                (particles_.vx[j] - particles_.vx[i]) * nx
                                + (particles_.vy[j] - particles_.vy[i]) * ny
                                + (particles_.vz[j] - particles_.vz[i]) * nz;
                            const Real forceMagnitude = conservativeForceMagnitude - damping * relativeNormalVelocity;
                            const Real fx = forceMagnitude * nx;
                            const Real fy = forceMagnitude * ny;
                            const Real fz = forceMagnitude * nz;

                            fxBuffer[i] -= fx;
                            fyBuffer[i] -= fy;
                            fzBuffer[i] -= fz;
                            fxBuffer[j] += fx;
                            fyBuffer[j] += fy;
                            fzBuffer[j] += fz;
                        }
                    }
                }
            }
        }
    });

    parallelFor(count, [&](std::size_t i) {
        Real fx = Real{0};
        Real fy = Real{0};
        Real fz = Real{0};
        for (std::size_t threadIndex = 0; threadIndex < pairThreadCount; ++threadIndex)
        {
            fx += localFx[threadIndex][i];
            fy += localFy[threadIndex][i];
            fz += localFz[threadIndex][i];
        }
        particles_.fx[i] += fx;
        particles_.fy[i] += fy;
        particles_.fz[i] += fz;
    });
}

void Simulation::integrate(Real dt)
{
    parallelFor(particles_.size(), [this, dt](std::size_t i) {
        const Real invMass = Real{1} / particles_.mass[i];
        particles_.vx[i] += particles_.fx[i] * invMass * dt;
        particles_.vy[i] += particles_.fy[i] * invMass * dt;
        particles_.vz[i] += particles_.fz[i] * invMass * dt;

        particles_.x[i] += particles_.vx[i] * dt;
        particles_.y[i] += particles_.vy[i] * dt;
        particles_.z[i] += particles_.vz[i] * dt;
        wrapPosition(i);
    });
}

void Simulation::resolveOverlaps()
{
    const std::size_t count = particles_.size();
    if (count < 2)
    {
        return;
    }

    const Real maxRadius = *std::max_element(particles_.radius.begin(), particles_.radius.end());
    const Real interactionDistance = std::max(Real{0.001}, maxRadius * Real{2});
    const std::array<Real, 3> boxSize{
        config_.box.size.x,
        config_.box.size.y,
        config_.box.size.z
    };
    const std::array<int, 3> dims{
        std::clamp(static_cast<int>(std::floor(boxSize[0] / interactionDistance)), 1, kMaxPairCellsPerAxis),
        std::clamp(static_cast<int>(std::floor(boxSize[1] / interactionDistance)), 1, kMaxPairCellsPerAxis),
        std::clamp(static_cast<int>(std::floor(boxSize[2] / interactionDistance)), 1, kMaxPairCellsPerAxis)
    };
    const int cellCount = dims[0] * dims[1] * dims[2];
    const Real distanceEpsilon = Real{1e-9};
    const Real correctionFraction = config_.forces.overlapCorrectionFraction;
    const Real slop = std::max(Real{1e-5}, config_.forces.pairRegularizationLength * Real{0.02});
    std::size_t correctionThreadCount = 1;
#if PARTICLE_ENABLE_PARALLEL
    if (static_cast<std::size_t>(cellCount) >= PARTICLE_PARALLEL_MIN_ITEMS && workerCount_ > 1 && !workers_.empty())
    {
        correctionThreadCount = std::min<std::size_t>(workerCount_, static_cast<std::size_t>(cellCount));
    }
#endif
    std::vector<std::vector<Real>> localDx(correctionThreadCount, std::vector<Real>(count, Real{0}));
    std::vector<std::vector<Real>> localDy(correctionThreadCount, std::vector<Real>(count, Real{0}));
    std::vector<std::vector<Real>> localDz(correctionThreadCount, std::vector<Real>(count, Real{0}));

    auto cellIndex = [dims](int ix, int iy, int iz) {
        ix = positiveModulo(ix, dims[0]);
        iy = positiveModulo(iy, dims[1]);
        iz = positiveModulo(iz, dims[2]);
        return (iz * dims[1] + iy) * dims[0] + ix;
    };
    auto particleCellCoord = [boxSize, dims](Real value, int axis) {
        const Real normalized = (value + boxSize[axis] * Real{0.5}) / boxSize[axis];
        return std::clamp(static_cast<int>(std::floor(normalized * static_cast<Real>(dims[axis]))), 0, dims[axis] - 1);
    };

    for (int iteration = 0; iteration < config_.forces.overlapCorrectionIterations; ++iteration)
    {
        std::vector<std::vector<std::size_t>> cells(static_cast<std::size_t>(cellCount));
        for (std::size_t i = 0; i < count; ++i)
        {
            wrapPosition(i);
            const int ix = particleCellCoord(particles_.x[i], 0);
            const int iy = particleCellCoord(particles_.y[i], 1);
            const int iz = particleCellCoord(particles_.z[i], 2);
            cells[static_cast<std::size_t>(cellIndex(ix, iy, iz))].push_back(i);
        }

        for (std::size_t threadIndex = 0; threadIndex < correctionThreadCount; ++threadIndex)
        {
            std::ranges::fill(localDx[threadIndex], Real{0});
            std::ranges::fill(localDy[threadIndex], Real{0});
            std::ranges::fill(localDz[threadIndex], Real{0});
        }

        parallelForIndexed(static_cast<std::size_t>(cellCount), [&](std::size_t threadIndex, std::size_t baseCellIndex) {
            const int baseCell = static_cast<int>(baseCellIndex);
            const auto& baseParticles = cells[baseCellIndex];
            if (baseParticles.empty())
            {
                return;
            }
            const int baseIz = baseCell / (dims[0] * dims[1]);
            const int baseRemainder = baseCell - baseIz * dims[0] * dims[1];
            const int baseIy = baseRemainder / dims[0];
            const int baseIx = baseRemainder - baseIy * dims[0];
            auto& dxBuffer = localDx[threadIndex];
            auto& dyBuffer = localDy[threadIndex];
            auto& dzBuffer = localDz[threadIndex];
            std::vector<int> visitedNeighborCells;
            visitedNeighborCells.reserve(27);

            for (int dz = -1; dz <= 1; ++dz)
            {
                for (int dy = -1; dy <= 1; ++dy)
                {
                    for (int dx = -1; dx <= 1; ++dx)
                    {
                        const int neighborCell = cellIndex(baseIx + dx, baseIy + dy, baseIz + dz);
                        if (neighborCell < baseCell)
                        {
                            continue;
                        }
                        if (std::ranges::find(visitedNeighborCells, neighborCell) != visitedNeighborCells.end())
                        {
                            continue;
                        }
                        visitedNeighborCells.push_back(neighborCell);
                        const auto& cellParticles = cells[static_cast<std::size_t>(neighborCell)];

                        for (const std::size_t i : baseParticles)
                        {
                            for (const std::size_t j : cellParticles)
                            {
                                if (neighborCell == baseCell && j <= i)
                                {
                                    continue;
                                }

                                Real rx = wrapPeriodic(particles_.x[j] - particles_.x[i], config_.box.size.x);
                                Real ry = wrapPeriodic(particles_.y[j] - particles_.y[i], config_.box.size.y);
                                Real rz = wrapPeriodic(particles_.z[j] - particles_.z[i], config_.box.size.z);
                                Real distanceSquared = rx * rx + ry * ry + rz * rz;
                                const Real radiusSum = particles_.radius[i] + particles_.radius[j];
                                if (distanceSquared >= radiusSum * radiusSum)
                                {
                                    continue;
                                }

                                Real distance = std::sqrt(distanceSquared);
                                if (distance < distanceEpsilon)
                                {
                                    rx = Real{1};
                                    ry = Real{0};
                                    rz = Real{0};
                                    distance = Real{1};
                                }

                                const Real overlap = radiusSum - distance;
                                if (overlap <= slop)
                                {
                                    continue;
                                }

                                const Real invDistance = Real{1} / distance;
                                const Real nx = rx * invDistance;
                                const Real ny = ry * invDistance;
                                const Real nz = rz * invDistance;
                                const Real invMassI = Real{1} / particles_.mass[i];
                                const Real invMassJ = Real{1} / particles_.mass[j];
                                const Real invMassSum = invMassI + invMassJ;
                                const Real correction = correctionFraction * (overlap - slop) / invMassSum;

                                dxBuffer[i] -= nx * correction * invMassI;
                                dyBuffer[i] -= ny * correction * invMassI;
                                dzBuffer[i] -= nz * correction * invMassI;
                                dxBuffer[j] += nx * correction * invMassJ;
                                dyBuffer[j] += ny * correction * invMassJ;
                                dzBuffer[j] += nz * correction * invMassJ;
                            }
                        }
                    }
                }
            }
        });

        parallelFor(count, [&](std::size_t i) {
            Real dx = Real{0};
            Real dy = Real{0};
            Real dz = Real{0};
            for (std::size_t threadIndex = 0; threadIndex < correctionThreadCount; ++threadIndex)
            {
                dx += localDx[threadIndex][i];
                dy += localDy[threadIndex][i];
                dz += localDz[threadIndex][i];
            }
            particles_.x[i] += dx;
            particles_.y[i] += dy;
            particles_.z[i] += dz;
            wrapPosition(i);
        });
    }
}

void Simulation::resolveImpulseCollisions()
{
    const std::size_t count = particles_.size();
    if (count < 2)
    {
        return;
    }

    const Real maxRadius = *std::max_element(particles_.radius.begin(), particles_.radius.end());
    const Real interactionDistance = std::max(Real{0.001}, maxRadius * Real{2});
    const std::array<Real, 3> boxSize{
        config_.box.size.x,
        config_.box.size.y,
        config_.box.size.z
    };
    const std::array<int, 3> dims{
        std::clamp(static_cast<int>(std::floor(boxSize[0] / interactionDistance)), 1, kMaxPairCellsPerAxis),
        std::clamp(static_cast<int>(std::floor(boxSize[1] / interactionDistance)), 1, kMaxPairCellsPerAxis),
        std::clamp(static_cast<int>(std::floor(boxSize[2] / interactionDistance)), 1, kMaxPairCellsPerAxis)
    };
    const int cellCount = dims[0] * dims[1] * dims[2];
    const Real distanceEpsilon = Real{1e-9};
    const Real restitution = config_.collisions.restitution;
    std::size_t collisionThreadCount = 1;
#if PARTICLE_ENABLE_PARALLEL
    if (static_cast<std::size_t>(cellCount) >= PARTICLE_PARALLEL_MIN_ITEMS && workerCount_ > 1 && !workers_.empty())
    {
        collisionThreadCount = std::min<std::size_t>(workerCount_, static_cast<std::size_t>(cellCount));
    }
#endif
    std::vector<std::vector<Real>> localDvx(collisionThreadCount, std::vector<Real>(count, Real{0}));
    std::vector<std::vector<Real>> localDvy(collisionThreadCount, std::vector<Real>(count, Real{0}));
    std::vector<std::vector<Real>> localDvz(collisionThreadCount, std::vector<Real>(count, Real{0}));
    std::vector<std::vector<std::size_t>> cells(static_cast<std::size_t>(cellCount));

    auto cellIndex = [dims](int ix, int iy, int iz) {
        ix = positiveModulo(ix, dims[0]);
        iy = positiveModulo(iy, dims[1]);
        iz = positiveModulo(iz, dims[2]);
        return (iz * dims[1] + iy) * dims[0] + ix;
    };
    auto particleCellCoord = [boxSize, dims](Real value, int axis) {
        const Real normalized = (value + boxSize[axis] * Real{0.5}) / boxSize[axis];
        return std::clamp(static_cast<int>(std::floor(normalized * static_cast<Real>(dims[axis]))), 0, dims[axis] - 1);
    };

    for (std::size_t i = 0; i < count; ++i)
    {
        wrapPosition(i);
        const int ix = particleCellCoord(particles_.x[i], 0);
        const int iy = particleCellCoord(particles_.y[i], 1);
        const int iz = particleCellCoord(particles_.z[i], 2);
        cells[static_cast<std::size_t>(cellIndex(ix, iy, iz))].push_back(i);
    }

    parallelForIndexed(static_cast<std::size_t>(cellCount), [&](std::size_t threadIndex, std::size_t baseCellIndex) {
        const int baseCell = static_cast<int>(baseCellIndex);
        const auto& baseParticles = cells[baseCellIndex];
        if (baseParticles.empty())
        {
            return;
        }
        const int baseIz = baseCell / (dims[0] * dims[1]);
        const int baseRemainder = baseCell - baseIz * dims[0] * dims[1];
        const int baseIy = baseRemainder / dims[0];
        const int baseIx = baseRemainder - baseIy * dims[0];
        auto& dvxBuffer = localDvx[threadIndex];
        auto& dvyBuffer = localDvy[threadIndex];
        auto& dvzBuffer = localDvz[threadIndex];
        std::vector<int> visitedNeighborCells;
        visitedNeighborCells.reserve(27);

        for (int dz = -1; dz <= 1; ++dz)
        {
            for (int dy = -1; dy <= 1; ++dy)
            {
                for (int dx = -1; dx <= 1; ++dx)
                {
                    const int neighborCell = cellIndex(baseIx + dx, baseIy + dy, baseIz + dz);
                    if (neighborCell < baseCell)
                    {
                        continue;
                    }
                    if (std::ranges::find(visitedNeighborCells, neighborCell) != visitedNeighborCells.end())
                    {
                        continue;
                    }
                    visitedNeighborCells.push_back(neighborCell);
                    const auto& cellParticles = cells[static_cast<std::size_t>(neighborCell)];

                    for (const std::size_t i : baseParticles)
                    {
                        for (const std::size_t j : cellParticles)
                        {
                            if (neighborCell == baseCell && j <= i)
                            {
                                continue;
                            }

                            Real rx = wrapPeriodic(particles_.x[j] - particles_.x[i], config_.box.size.x);
                            Real ry = wrapPeriodic(particles_.y[j] - particles_.y[i], config_.box.size.y);
                            Real rz = wrapPeriodic(particles_.z[j] - particles_.z[i], config_.box.size.z);
                            Real distanceSquared = rx * rx + ry * ry + rz * rz;
                            const Real radiusSum = particles_.radius[i] + particles_.radius[j];
                            if (distanceSquared >= radiusSum * radiusSum)
                            {
                                continue;
                            }

                            Real distance = std::sqrt(distanceSquared);
                            if (distance < distanceEpsilon)
                            {
                                rx = Real{1};
                                ry = Real{0};
                                rz = Real{0};
                                distance = Real{1};
                            }

                            const Real invDistance = Real{1} / distance;
                            const Real nx = rx * invDistance;
                            const Real ny = ry * invDistance;
                            const Real nz = rz * invDistance;
                            const Real relativeNormalVelocity =
                                (particles_.vx[j] - particles_.vx[i]) * nx
                                + (particles_.vy[j] - particles_.vy[i]) * ny
                                + (particles_.vz[j] - particles_.vz[i]) * nz;
                            if (relativeNormalVelocity >= Real{0})
                            {
                                continue;
                            }

                            const Real invMassI = Real{1} / particles_.mass[i];
                            const Real invMassJ = Real{1} / particles_.mass[j];
                            const Real invMassSum = invMassI + invMassJ;
                            const Real impulse = -(Real{1} + restitution) * relativeNormalVelocity / invMassSum;
                            dvxBuffer[i] -= nx * impulse * invMassI;
                            dvyBuffer[i] -= ny * impulse * invMassI;
                            dvzBuffer[i] -= nz * impulse * invMassI;
                            dvxBuffer[j] += nx * impulse * invMassJ;
                            dvyBuffer[j] += ny * impulse * invMassJ;
                            dvzBuffer[j] += nz * impulse * invMassJ;
                        }
                    }
                }
            }
        }
    });

    parallelFor(count, [&](std::size_t i) {
        Real dvx = Real{0};
        Real dvy = Real{0};
        Real dvz = Real{0};
        for (std::size_t threadIndex = 0; threadIndex < collisionThreadCount; ++threadIndex)
        {
            dvx += localDvx[threadIndex][i];
            dvy += localDvy[threadIndex][i];
            dvz += localDvz[threadIndex][i];
        }
        particles_.vx[i] += dvx;
        particles_.vy[i] += dvy;
        particles_.vz[i] += dvz;
    });
}

void Simulation::wrapPosition(std::size_t index)
{
    particles_.x[index] = wrapPeriodic(particles_.x[index], config_.box.size.x);
    particles_.y[index] = wrapPeriodic(particles_.y[index], config_.box.size.y);
    particles_.z[index] = wrapPeriodic(particles_.z[index], config_.box.size.z);
}
