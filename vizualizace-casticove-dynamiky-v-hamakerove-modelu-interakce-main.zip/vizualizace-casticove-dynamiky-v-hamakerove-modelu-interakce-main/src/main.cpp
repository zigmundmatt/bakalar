#include "app.hpp"

int main(int argc, char* argv[])
{
    bool serverMode = (argc > 1 && std::string(argv[1]) == "--server");
    App().run(serverMode);
    return 0;
}

#if defined(_MSC_VER)
int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE hInstPrev, PSTR cmdline, int cmdshow) { return main(); }
#endif
