#include "app.hpp"
#include "vfs.h"

#include <algorithm>
#include <cstdint>
#include <chrono>
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>
#include <optional>
#include <sstream>
#include <utility>
#if defined(__linux__)
#include <unistd.h>
#endif

namespace
{
constexpr int kInitialParticleCount = 256;
constexpr int kMinParticleCount = 1;
constexpr int kMaxParticleCount = 20000;
constexpr Real kFrameDt = Real{1} / Real{120};
constexpr Real kBaseIntegrationDt = kFrameDt / static_cast<Real>(kPhysicsSubsteps);
constexpr int kUiFrameMs = 33;

struct CpuSample
{
    long long totalTicks = 0;
    long long idleTicks = 0;
    long long processTicks = 0;
};

void quietWebuiLogger(size_t, const char*, void*)
{
}

struct QuietWebuiLoggerInitializer
{
    QuietWebuiLoggerInitializer()
    {
        webui::set_logger(quietWebuiLogger);
    }
};

const QuietWebuiLoggerInitializer kQuietWebuiLoggerInitializer;

int clampedParticleCount(long long value)
{
    return std::clamp(static_cast<int>(value), kMinParticleCount, kMaxParticleCount);
}

int clampedSmallCount(long long value)
{
    return std::clamp(static_cast<int>(value), 1, 5000);
}

template <typename T>
void appendVectorBytes(std::string& payload, const std::vector<T>& values)
{
    const auto* bytes = reinterpret_cast<const char*>(values.data());
    payload.append(bytes, values.size() * sizeof(T));
}

std::optional<CpuSample> readCpuSample()
{
#if defined(__linux__)
    std::ifstream statFile("/proc/stat");
    std::string cpuLabel;
    long long user = 0;
    long long nice = 0;
    long long system = 0;
    long long idle = 0;
    long long iowait = 0;
    long long irq = 0;
    long long softirq = 0;
    long long steal = 0;
    long long guest = 0;
    long long guestNice = 0;
    if (!(statFile >> cpuLabel >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal >> guest >> guestNice))
    {
        return std::nullopt;
    }

    std::ifstream processStatFile("/proc/self/stat");
    std::string processStat;
    std::getline(processStatFile, processStat);
    const std::size_t endCommand = processStat.rfind(')');
    if (endCommand == std::string::npos || endCommand + 2 >= processStat.size())
    {
        return std::nullopt;
    }

    std::istringstream processFields(processStat.substr(endCommand + 2));
    std::string field;
    long long utime = 0;
    long long stime = 0;
    for (int index = 3; processFields >> field; ++index)
    {
        if (index == 14)
        {
            utime = std::stoll(field);
        }
        else if (index == 15)
        {
            stime = std::stoll(field);
            break;
        }
    }

    const long long idleTicks = idle + iowait;
    const long long totalTicks = user + nice + system + idle + iowait + irq + softirq + steal + guest + guestNice;
    return CpuSample{
        .totalTicks = totalTicks,
        .idleTicks = idleTicks,
        .processTicks = utime + stime
    };
#else
    return std::nullopt;
#endif
}

}

App::App()
{
    window_.bind("setRunningB", this, &App::setRunningB);
    window_.bind("resetSimulationB", this, &App::resetSimulationB);
    window_.bind("twoParticleTestB", this, &App::twoParticleTestB);
    window_.bind("setParticleCountB", this, &App::setParticleCountB);
    window_.bind("addParticlesB", this, &App::addParticlesB);
    window_.bind("removeParticlesB", this, &App::removeParticlesB);
    window_.bind("setIntegrationDtB", this, &App::setIntegrationDtB);
    window_.bind("setBoxB", this, &App::setBoxB);
    window_.bind("setRadiusDistributionB", this, &App::setRadiusDistributionB);
    window_.bind("setDampingEnabledB", this, &App::setDampingEnabledB);
    window_.bind("setConstantFieldEnabledB", this, &App::setConstantFieldEnabledB);
    window_.bind("setPairInteractionEnabledB", this, &App::setPairInteractionEnabledB);
    window_.bind("setPairInteractionParamsB", this, &App::setPairInteractionParamsB);
    window_.bind("setOverlapCorrectionEnabledB", this, &App::setOverlapCorrectionEnabledB);
    window_.bind("setContactModelB", this, &App::setContactModelB);
    window_.bind("setCollisionsEnabledB", this, &App::setCollisionsEnabledB);
    window_.bind("setRestitutionB", this, &App::setRestitutionB);
    simulation_.reset(kInitialParticleCount);
}

void App::run(bool serverMode)
{
    webui::set_config(use_cookies, false);

    window_.set_file_handler(vfs);
    if (serverMode)
    {
        window_.set_port(8080);
        std::string_view url = window_.start_server("index.html");
        std::cout << "Server running at " << url << std::endl;
    }
    else
    {
        char startMaximized[] = "--start-maximized";
        window_.set_custom_parameters(startMaximized);
        window_.show_browser("index.html", Chromium);
        window_.maximize();
    }

    std::jthread simulationWorker([this](std::stop_token stopToken) {
        simulationLoop(stopToken);
    });
    std::jthread uiWorker([this](std::stop_token stopToken) {
        uiLoop(stopToken);
    });
    webui::wait();
}

void App::enqueue(SimulationCommand command)
{
    std::lock_guard lock(commandsMutex_);
    commands_.push_back(std::move(command));
}

void App::applyPendingCommands()
{
    std::deque<SimulationCommand> commands;
    {
        std::lock_guard lock(commandsMutex_);
        commands.swap(commands_);
    }

    for (const SimulationCommand& command : commands)
    {
        std::lock_guard simulationLock(simulationMutex_);
        std::visit([this](const auto& value) { simulation_.apply(value); }, command);
    }
}

std::string App::simulationPayload() const
{
    const SimulationSnapshot snapshot = simulation_.snapshot();
    const ParallelStats parallel = simulation_.parallelStats();
    const ParticleStore& particles = *snapshot.particles;

    nlohmann::json data;
    data["running"] = snapshot.config.running;
    data["timeScale"] = snapshot.config.timeScale;
    data["time"] = {
        {"frameDt", kFrameDt},
        {"physicsSubsteps", kPhysicsSubsteps},
        {"baseIntegrationDt", kBaseIntegrationDt},
        {"integrationDt", kBaseIntegrationDt * snapshot.config.timeScale},
        {"simulationTime", snapshot.simulationTime},
        {"integrationSteps", snapshot.integrationSteps},
        {"uiFrameMs", kUiFrameMs}
    };
    data["simulationFps"] = simulationFps_;
    data["cpu"] = {
        {"available", cpuTelemetryAvailable_},
        {"processPercent", processCpuPercent_},
        {"processCores", processCpuCores_},
        {"systemPercent", systemCpuPercent_}
    };
    data["transport"] = {
        {"payloadBytes", uiPayloadBytes_},
        {"encodeMs", uiEncodeMs_},
        {"sendMs", uiSendMs_},
        {"stepMs", simulationStepMs_}
    };
    data["particleCount"] = particles.size();
    data["box"] = {
        {"x", snapshot.config.box.size.x},
        {"y", snapshot.config.box.size.y},
        {"z", snapshot.config.box.size.z}
    };
    data["radiusDistribution"] = {
        {"medianRadiusUm", snapshot.config.radiusDistribution.medianRadiusUm},
        {"logSigma", snapshot.config.radiusDistribution.logSigma}
    };
    data["forces"] = {
        {"dampingEnabled", snapshot.config.forces.dampingEnabled},
        {"constantFieldEnabled", snapshot.config.forces.constantFieldEnabled},
        {"pairInteractionEnabled", snapshot.config.forces.pairInteractionEnabled},
        {"pairForceScale", snapshot.config.forces.pairForceScale},
        {"pairRegularizationLength", snapshot.config.forces.pairRegularizationLength},
        {"pairCutoffGap", snapshot.config.forces.pairCutoffGap},
        {"pairDamping", snapshot.config.forces.pairDamping},
        {"contactModel", static_cast<int>(snapshot.config.forces.contactModel)},
        {"overlapCorrectionEnabled", snapshot.config.forces.overlapCorrectionEnabled},
        {"overlapCorrectionIterations", snapshot.config.forces.overlapCorrectionIterations},
        {"overlapCorrectionFraction", snapshot.config.forces.overlapCorrectionFraction}
    };
    data["collisions"] = {
        {"enabled", snapshot.config.collisions.enabled},
        {"restitution", snapshot.config.collisions.restitution}
    };
    data["parallel"] = {
        {"enabled", parallel.enabled},
        {"hardwareThreads", parallel.hardwareThreads},
        {"configuredWorkers", parallel.configuredWorkers},
        {"lastStepThreads", parallel.lastStepThreads},
        {"lastStepItems", parallel.lastStepItems},
        {"minItems", parallel.minItems}
    };

    data["binary"] = {
        {"realBytes", sizeof(Real)}
    };

    const std::string header = data.dump();
    const std::uint32_t headerSize = static_cast<std::uint32_t>(header.size());
    std::string payload;
    payload.reserve(sizeof(headerSize) + header.size()
        + particles.size() * (sizeof(Real) * 4 + sizeof(std::uint16_t)) + 16);
    payload.append(reinterpret_cast<const char*>(&headerSize), sizeof(headerSize));
    payload.append(header);
    appendVectorBytes(payload, particles.x);
    appendVectorBytes(payload, particles.y);
    appendVectorBytes(payload, particles.z);
    appendVectorBytes(payload, particles.radius);
    appendVectorBytes(payload, particles.type);

    return payload;
}

void App::simulationLoop(std::stop_token stopToken)
{
    auto lastFpsFrame = std::chrono::steady_clock::now();
    std::optional<CpuSample> previousCpuSample = readCpuSample();
    int simulationSteps = 0;

    while (!stopToken.stop_requested())
    {
        applyPendingCommands();
        bool wasRunning = false;
        const auto stepStart = std::chrono::steady_clock::now();
        {
            std::lock_guard simulationLock(simulationMutex_);
            wasRunning = simulation_.snapshot().config.running;
            simulation_.step(kFrameDt);
        }
        const auto stepEnd = std::chrono::steady_clock::now();
        {
            std::lock_guard simulationLock(simulationMutex_);
            simulationStepMs_ = std::chrono::duration<double, std::milli>(stepEnd - stepStart).count();
        }
        if (wasRunning)
        {
            ++simulationSteps;
        }

        const auto now = std::chrono::steady_clock::now();
        const auto fpsElapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastFpsFrame);
        if (fpsElapsedMs.count() >= 1000)
        {
            {
                std::lock_guard simulationLock(simulationMutex_);
                simulationFps_ = simulationSteps;
            }
            simulationSteps = 0;
            lastFpsFrame = now;

            if (std::optional<CpuSample> currentCpuSample = readCpuSample(); currentCpuSample && previousCpuSample)
            {
                const long long totalDelta = currentCpuSample->totalTicks - previousCpuSample->totalTicks;
                const long long idleDelta = currentCpuSample->idleTicks - previousCpuSample->idleTicks;
                const long long processDelta = currentCpuSample->processTicks - previousCpuSample->processTicks;
                if (totalDelta > 0)
                {
                    const unsigned int hardwareThreads = std::max(1U, std::thread::hardware_concurrency());
                    std::lock_guard simulationLock(simulationMutex_);
                    cpuTelemetryAvailable_ = true;
                    systemCpuPercent_ = 100.0 * static_cast<double>(totalDelta - idleDelta) / static_cast<double>(totalDelta);
                    processCpuPercent_ = 100.0 * static_cast<double>(processDelta) / static_cast<double>(totalDelta);
                    processCpuCores_ = static_cast<double>(processDelta) * static_cast<double>(hardwareThreads)
                        / static_cast<double>(totalDelta);
                }
                previousCpuSample = currentCpuSample;
            }
            else
            {
                std::lock_guard simulationLock(simulationMutex_);
                cpuTelemetryAvailable_ = false;
                previousCpuSample = currentCpuSample;
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(8));
    }
}

void App::uiLoop(std::stop_token stopToken)
{
    auto lastUiFrame = std::chrono::steady_clock::now();

    while (!stopToken.stop_requested())
    {
        const auto now = std::chrono::steady_clock::now();
        const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastUiFrame);
        if (elapsedMs.count() < kUiFrameMs)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
            continue;
        }

        const auto encodeStart = std::chrono::steady_clock::now();
        std::string raw;
        {
            std::lock_guard simulationLock(simulationMutex_);
            raw = simulationPayload();
        }
        const auto encodeEnd = std::chrono::steady_clock::now();
        {
            std::lock_guard simulationLock(simulationMutex_);
            uiPayloadBytes_ = raw.size();
            uiEncodeMs_ = std::chrono::duration<double, std::milli>(encodeEnd - encodeStart).count();
        }

        const auto sendStart = std::chrono::steady_clock::now();
        window_.send_raw("simulationUpdate", raw.data(), raw.size());
        const auto sendEnd = std::chrono::steady_clock::now();
        {
            std::lock_guard simulationLock(simulationMutex_);
            uiSendMs_ = std::chrono::duration<double, std::milli>(sendEnd - sendStart).count();
        }
        lastUiFrame = now;
    }
}

void App::setRunningB(webui::window::event* e)
{
    const bool running = e->get_bool();
    enqueue(SetRunningCommand{running});
    e->return_bool(running);
}

void App::resetSimulationB(webui::window::event* e)
{
    enqueue(SetRunningCommand{false});
    enqueue(RegenerateParticlesCommand{});
    e->return_bool(true);
}

void App::twoParticleTestB(webui::window::event* e)
{
    const int surfaceGapNm = std::clamp(static_cast<int>(e->get_int()), 0, 20000);
    enqueue(ConfigureTwoParticleTestCommand{static_cast<Real>(surfaceGapNm) / Real{1000}});
    e->return_int(surfaceGapNm);
}

void App::setParticleCountB(webui::window::event* e)
{
    const int particleCount = clampedParticleCount(e->get_int());
    enqueue(SetParticleCountCommand{particleCount});
    e->return_int(particleCount);
}

void App::addParticlesB(webui::window::event* e)
{
    const int count = clampedSmallCount(e->get_int());
    enqueue(AddParticlesCommand{count});
    e->return_int(count);
}

void App::removeParticlesB(webui::window::event* e)
{
    const int count = clampedSmallCount(e->get_int());
    enqueue(RemoveParticlesCommand{count});
    e->return_int(count);
}

void App::setIntegrationDtB(webui::window::event* e)
{
    constexpr int kMinIntegrationDtUs = 1;
    constexpr int kMaxIntegrationDtUs = static_cast<int>(kBaseIntegrationDt * Real{5} * Real{1000000});
    const int requestedUs = std::clamp(static_cast<int>(e->get_int()), kMinIntegrationDtUs, kMaxIntegrationDtUs);
    const Real integrationDt = static_cast<Real>(requestedUs) / Real{1000000};
    enqueue(SetTimeScaleCommand{integrationDt / kBaseIntegrationDt});
    e->return_int(requestedUs);
}

void App::setBoxB(webui::window::event* e)
{
    Box box;
    box.size.x = std::clamp(static_cast<Real>(e->get_int(0)), Real{1}, Real{400});
    box.size.y = std::clamp(static_cast<Real>(e->get_int(1)), Real{1}, Real{400});
    box.size.z = std::clamp(static_cast<Real>(e->get_int(2)), Real{1}, Real{400});
    enqueue(SetBoxCommand{box});

    const std::string response = std::to_string(static_cast<int>(box.size.x)) + ";"
        + std::to_string(static_cast<int>(box.size.y)) + ";"
        + std::to_string(static_cast<int>(box.size.z));
    e->return_string(response);
}

void App::setRadiusDistributionB(webui::window::event* e)
{
    const int medianNm = std::clamp(static_cast<int>(e->get_int(0)), 5, 2000);
    const int logSigmaPercent = std::clamp(static_cast<int>(e->get_int(1)), 1, 150);

    RadiusDistributionConfig distribution;
    distribution.medianRadiusUm = static_cast<Real>(medianNm) / Real{1000};
    distribution.logSigma = static_cast<Real>(logSigmaPercent) / Real{100};
    enqueue(SetRadiusDistributionCommand{distribution});

    const std::string response = std::to_string(medianNm) + ";" + std::to_string(logSigmaPercent);
    e->return_string(response);
}

void App::setDampingEnabledB(webui::window::event* e)
{
    const bool enabled = e->get_bool();
    enqueue(SetDampingEnabledCommand{enabled});
    e->return_bool(enabled);
}

void App::setConstantFieldEnabledB(webui::window::event* e)
{
    const bool enabled = e->get_bool();
    enqueue(SetConstantFieldEnabledCommand{enabled});
    e->return_bool(enabled);
}

void App::setPairInteractionEnabledB(webui::window::event* e)
{
    const bool enabled = e->get_bool();
    enqueue(SetPairInteractionEnabledCommand{enabled});
    e->return_bool(enabled);
}

void App::setPairInteractionParamsB(webui::window::event* e)
{
    const int forceScaleUnits = std::clamp(static_cast<int>(e->get_int(0)), 0, 1000);
    const int regularizationNm = std::clamp(static_cast<int>(e->get_int(1)), 1, 2000);
    const int cutoffNm = std::clamp(static_cast<int>(e->get_int(2)), 5, 20000);
    const int dampingUnits = std::clamp(static_cast<int>(e->get_int(3)), 0, 2000);
    const int correctionIterations = std::clamp(static_cast<int>(e->get_int(4)), 1, 16);
    const int correctionPercent = std::clamp(static_cast<int>(e->get_int(5)), 5, 95);

    SetPairInteractionParamsCommand command;
    command.forceScale = static_cast<Real>(forceScaleUnits) * Real{0.0001};
    command.regularizationLength = static_cast<Real>(regularizationNm) / Real{1000};
    command.cutoffGap = static_cast<Real>(cutoffNm) / Real{1000};
    command.damping = static_cast<Real>(dampingUnits) * Real{0.001};
    command.overlapCorrectionIterations = correctionIterations;
    command.overlapCorrectionFraction = static_cast<Real>(correctionPercent) / Real{100};
    enqueue(command);

    const std::string response = std::to_string(forceScaleUnits) + ";"
        + std::to_string(regularizationNm) + ";"
        + std::to_string(cutoffNm) + ";"
        + std::to_string(dampingUnits) + ";"
        + std::to_string(correctionIterations) + ";"
        + std::to_string(correctionPercent);
    e->return_string(response);
}

void App::setOverlapCorrectionEnabledB(webui::window::event* e)
{
    const bool enabled = e->get_bool();
    enqueue(SetOverlapCorrectionEnabledCommand{enabled});
    e->return_bool(enabled);
}

void App::setContactModelB(webui::window::event* e)
{
    const int model = std::clamp(static_cast<int>(e->get_int()), 0, 2);
    enqueue(SetContactModelCommand{static_cast<ContactModel>(model)});
    e->return_int(model);
}

void App::setCollisionsEnabledB(webui::window::event* e)
{
    const bool enabled = e->get_bool();
    enqueue(SetCollisionsEnabledCommand{enabled});
    e->return_bool(enabled);
}

void App::setRestitutionB(webui::window::event* e)
{
    const int percent = std::clamp(static_cast<int>(e->get_int()), 0, 100);
    enqueue(SetRestitutionCommand{static_cast<Real>(percent) / Real{100}});
    e->return_int(percent);
}
