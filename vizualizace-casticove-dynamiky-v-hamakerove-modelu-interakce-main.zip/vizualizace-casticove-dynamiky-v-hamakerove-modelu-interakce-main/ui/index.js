import * as THREE from "three";
import { OrbitControls } from "./vendor/OrbitControls.js";

const sceneHost = document.getElementById("scene");
const connectionState = document.getElementById("connectionState");
const particleCountLabel = document.getElementById("particleCount");
const simulationTimeStatus = document.getElementById("simulationTimeStatus");
const simulationFpsCounter = document.getElementById("simulationFpsCounter");
const renderFpsCounter = document.getElementById("renderFpsCounter");
const parallelStatus = document.getElementById("parallelStatus");
const cpuLoadStatus = document.getElementById("cpuLoadStatus");
const transportStatus = document.getElementById("transportStatus");
const toggleRunningButton = document.getElementById("toggleRunning");
const resetButton = document.getElementById("resetSimulation");
const twoParticleTestButton = document.getElementById("twoParticleTest");
const twoParticleDistance = document.getElementById("twoParticleDistance");
const particleSlider = document.getElementById("particleSlider");
const particleNumber = document.getElementById("particleNumber");
const particleValue = document.getElementById("particleValue");
const dtSlider = document.getElementById("dtSlider");
const dtValue = document.getElementById("dtValue");
const stabilityStatus = document.getElementById("stabilityStatus");
const boxX = document.getElementById("boxX");
const boxY = document.getElementById("boxY");
const boxZ = document.getElementById("boxZ");
const medianRadiusSlider = document.getElementById("medianRadiusSlider");
const medianRadiusValue = document.getElementById("medianRadiusValue");
const logSigmaSlider = document.getElementById("logSigmaSlider");
const logSigmaValue = document.getElementById("logSigmaValue");
const distributionChart = document.getElementById("distributionChart");
const dampingToggle = document.getElementById("dampingToggle");
const fieldToggle = document.getElementById("fieldToggle");
const pairInteractionToggle = document.getElementById("pairInteractionToggle");
const pairForceScaleSlider = document.getElementById("pairForceScaleSlider");
const pairForceScaleValue = document.getElementById("pairForceScaleValue");
const pairRegularizationSlider = document.getElementById("pairRegularizationSlider");
const pairRegularizationValue = document.getElementById("pairRegularizationValue");
const pairCutoffSlider = document.getElementById("pairCutoffSlider");
const pairCutoffValue = document.getElementById("pairCutoffValue");
const cutoffStepStatus = document.getElementById("cutoffStepStatus");
const pairDampingSlider = document.getElementById("pairDampingSlider");
const pairDampingValue = document.getElementById("pairDampingValue");
const contactModelSelect = document.getElementById("contactModelSelect");
const overlapCorrectionToggle = document.getElementById("overlapCorrectionToggle");
const overlapIterationsSlider = document.getElementById("overlapIterationsSlider");
const overlapIterationsValue = document.getElementById("overlapIterationsValue");
const overlapStrengthSlider = document.getElementById("overlapStrengthSlider");
const overlapStrengthValue = document.getElementById("overlapStrengthValue");
const collisionToggle = document.getElementById("collisionToggle");
const restitutionSlider = document.getElementById("restitutionSlider");
const restitutionValue = document.getElementById("restitutionValue");
const boxToggle = document.getElementById("boxToggle");
const axisLabelsToggle = document.getElementById("axisLabelsToggle");
const gridToggle = document.getElementById("gridToggle");
const periodicImagesToggle = document.getElementById("periodicImagesToggle");
const particleClipToggle = document.getElementById("particleClipToggle");
const resetViewButton = document.getElementById("resetView");

const typeColors = [
  new THREE.Color("#3b82f6"),
  new THREE.Color("#f97316"),
  new THREE.Color("#22c55e"),
  new THREE.Color("#e11d48"),
  new THREE.Color("#a855f7"),
  new THREE.Color("#14b8a6")
];

const state = {
  running: false,
  box: { x: 10, y: 10, z: 10 },
  particles: { x: [], y: [], z: [], r: [], type: [] },
  particleCount: 0,
  simulationFps: 0,
  timeScale: 1,
  time: {
    frameDt: 1 / 120,
    physicsSubsteps: 4,
    baseIntegrationDt: 1 / 480,
    integrationDt: 1 / 480,
    simulationTime: 0,
    integrationSteps: 0,
    uiFrameMs: 33
  },
  cpu: {
    available: false,
    processPercent: 0,
    processCores: 0,
    systemPercent: 0
  },
  transport: {
    payloadBytes: 0,
    encodeMs: 0,
    sendMs: 0,
    stepMs: 0
  },
  parallel: {
    enabled: false,
    hardwareThreads: 1,
    configuredWorkers: 1,
    lastStepThreads: 0,
    lastStepItems: 0,
    minItems: 256
  },
  radiusDistribution: { medianRadiusUm: 0.1, logSigma: 0.35 },
  forces: {
    dampingEnabled: false,
    constantFieldEnabled: false,
    pairInteractionEnabled: true,
    pairForceScale: 0.0005,
    pairRegularizationLength: 0.05,
    pairCutoffGap: 0.5,
    pairDamping: 0.02,
    contactModel: 0,
    overlapCorrectionEnabled: false,
    overlapCorrectionIterations: 4,
    overlapCorrectionFraction: 0.45
  },
  collisions: { enabled: false, restitution: 1.0 }
};

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setClearColor(0x14181c, 1);
renderer.localClippingEnabled = true;
sceneHost.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.fog = null;

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
const defaultCameraPosition = new THREE.Vector3(26, 20, 32);
const defaultCameraTarget = new THREE.Vector3(0, 0, 0);
camera.position.copy(defaultCameraPosition);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.target.copy(defaultCameraTarget);

scene.add(new THREE.AmbientLight(0xffffff, 1.9));
scene.add(new THREE.HemisphereLight(0xf4f8ff, 0xb7c6d6, 1.4));
const keyLight = new THREE.DirectionalLight(0xffffff, 1.6);
keyLight.position.set(10, 16, 8);
scene.add(keyLight);
const fillLight = new THREE.DirectionalLight(0xdbeafe, 1.1);
fillLight.position.set(-12, -8, -10);
scene.add(fillLight);

const particleGeometry = new THREE.SphereGeometry(1, 16, 10);
const particleMaterial = new THREE.MeshStandardMaterial({
  roughness: 0.82,
  metalness: 0.0,
  emissive: 0x161a1f,
  emissiveIntensity: 0.18
});
let particleMesh = null;
let particleCapacity = 0;
const matrix = new THREE.Matrix4();
const dummy = new THREE.Object3D();
const renderInstances = [];
const instanceColorKeys = [];
const boxClipPlanes = [
  new THREE.Plane(new THREE.Vector3(1, 0, 0), state.box.x * 0.5),
  new THREE.Plane(new THREE.Vector3(-1, 0, 0), state.box.x * 0.5),
  new THREE.Plane(new THREE.Vector3(0, 1, 0), state.box.y * 0.5),
  new THREE.Plane(new THREE.Vector3(0, -1, 0), state.box.y * 0.5),
  new THREE.Plane(new THREE.Vector3(0, 0, 1), state.box.z * 0.5),
  new THREE.Plane(new THREE.Vector3(0, 0, -1), state.box.z * 0.5)
];

let boxHelper = new THREE.LineSegments(
  new THREE.EdgesGeometry(new THREE.BoxGeometry(state.box.x, state.box.y, state.box.z)),
  new THREE.LineBasicMaterial({ color: 0x9fb0bf, transparent: true, opacity: 0.46 })
);
scene.add(boxHelper);

const axisLabels = new THREE.Group();
const gridGroup = new THREE.Group();
scene.add(axisLabels);
scene.add(gridGroup);

let frames = 0;
let fpsTimestamp = performance.now();
let distributionUpdateTimer = 0;
let pairInteractionUpdateTimer = 0;

function ensureParticleCapacity(count) {
  if (particleMesh && particleCapacity >= count) {
    return false;
  }

  if (particleMesh) {
    scene.remove(particleMesh);
  }

  particleCapacity = Math.max(1, Math.ceil(count * 1.25));
  particleMesh = new THREE.InstancedMesh(particleGeometry, particleMaterial, particleCapacity);
  particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  particleMesh.count = 0;
  scene.add(particleMesh);
  return true;
}

function updateBox() {
  scene.remove(boxHelper);
  boxHelper.geometry.dispose();
  boxHelper = new THREE.LineSegments(
    new THREE.EdgesGeometry(new THREE.BoxGeometry(state.box.x, state.box.y, state.box.z)),
    boxHelper.material
  );
  boxHelper.visible = boxToggle.checked;
  scene.add(boxHelper);

  const maxBoxSize = Math.max(state.box.x, state.box.y, state.box.z);
  controls.maxDistance = maxBoxSize * 6;
  controls.minDistance = Math.max(2, maxBoxSize * 0.12);
  updateAxisLabels();
  updateGrid();
  updateClipPlanes();
}

function makeTextSprite(text, color) {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  const scale = 2;
  canvas.width = 180 * scale;
  canvas.height = 72 * scale;
  ctx.scale(scale, scale);
  ctx.font = "600 28px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "rgba(16, 19, 22, 0.78)";
  ctx.fillRect(14, 12, 152, 48);
  ctx.strokeStyle = "rgba(238, 242, 245, 0.18)";
  ctx.strokeRect(14.5, 12.5, 151, 47);
  ctx.fillStyle = color;
  ctx.fillText(text, 90, 36);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthTest: false
  });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(1.55, 0.62, 1);
  return sprite;
}

function clearGroup(group) {
  for (const child of group.children) {
    child.geometry?.dispose();
    child.material?.map?.dispose();
    child.material?.dispose();
  }
  group.clear();
}

function updateAxisLabels() {
  clearGroup(axisLabels);
  const offset = Math.max(state.box.x, state.box.y, state.box.z) * 0.08 + 0.55;
  const minX = -state.box.x * 0.5;
  const minY = -state.box.y * 0.5;
  const minZ = -state.box.z * 0.5;
  const maxX = state.box.x * 0.5;
  const maxY = state.box.y * 0.5;
  const maxZ = state.box.z * 0.5;
  const labels = [
    { text: "X / um", color: "#f97316", position: [maxX + offset, minY, minZ] },
    { text: "Y / um", color: "#22c55e", position: [minX, maxY + offset, minZ] },
    { text: "Z / um", color: "#3b82f6", position: [minX, minY, maxZ + offset] }
  ];

  for (const label of labels) {
    const sprite = makeTextSprite(label.text, label.color);
    sprite.position.set(...label.position);
    axisLabels.add(sprite);
  }
  axisLabels.visible = axisLabelsToggle.checked;
}

function updateGrid() {
  clearGroup(gridGroup);
  const maxBoxSize = Math.max(state.box.x, state.box.y, state.box.z);
  const divisions = Math.max(2, Math.min(40, Math.round(maxBoxSize)));
  const gridSize = maxBoxSize;
  const material = new THREE.LineBasicMaterial({
    color: 0x6b7785,
    transparent: true,
    opacity: 0.26
  });

  const xy = new THREE.GridHelper(gridSize, divisions, 0x9fb0bf, 0x4b5563);
  xy.material = material.clone();
  xy.rotation.x = Math.PI / 2;
  xy.scale.x = state.box.x / maxBoxSize;
  xy.scale.z = state.box.y / maxBoxSize;
  xy.position.z = -state.box.z * 0.5;
  gridGroup.add(xy);

  const xz = new THREE.GridHelper(gridSize, divisions, 0x9fb0bf, 0x4b5563);
  xz.material = material.clone();
  xz.scale.x = state.box.x / maxBoxSize;
  xz.scale.z = state.box.z / maxBoxSize;
  xz.position.y = -state.box.y * 0.5;
  gridGroup.add(xz);

  const yz = new THREE.GridHelper(gridSize, divisions, 0x9fb0bf, 0x4b5563);
  yz.material = material.clone();
  yz.rotation.z = Math.PI / 2;
  yz.scale.x = state.box.y / maxBoxSize;
  yz.scale.z = state.box.z / maxBoxSize;
  yz.position.x = -state.box.x * 0.5;
  gridGroup.add(yz);

  material.dispose();
  gridGroup.visible = gridToggle.checked;
}

function updateClipPlanes() {
  boxClipPlanes[0].constant = state.box.x * 0.5;
  boxClipPlanes[1].constant = state.box.x * 0.5;
  boxClipPlanes[2].constant = state.box.y * 0.5;
  boxClipPlanes[3].constant = state.box.y * 0.5;
  boxClipPlanes[4].constant = state.box.z * 0.5;
  boxClipPlanes[5].constant = state.box.z * 0.5;
  updateParticleClipping();
}

function updateParticleClipping() {
  particleMaterial.clippingPlanes = particleClipToggle.checked ? boxClipPlanes : [];
  particleMaterial.clipIntersection = false;
  particleMaterial.needsUpdate = true;
}

function resetView() {
  controls.target.copy(defaultCameraTarget);
  camera.up.set(0, 1, 0);
  camera.position.copy(defaultCameraPosition);
  camera.lookAt(controls.target);
  controls.update();
}

function addRenderInstance(index, x, y, z) {
  renderInstances.push({ index, x, y, z });
}

function buildRenderInstances(particles, visualScale) {
  renderInstances.length = 0;

  const halfX = state.box.x * 0.5;
  const halfY = state.box.y * 0.5;
  const halfZ = state.box.z * 0.5;

  for (let i = 0; i < particles.x.length; i += 1) {
    const x = particles.x[i];
    const y = particles.y[i];
    const z = particles.z[i];
    addRenderInstance(i, x, y, z);

    if (!periodicImagesToggle.checked) {
      continue;
    }

    const margin = particles.r[i] * visualScale;
    const offsetsX = [0];
    const offsetsY = [0];
    const offsetsZ = [0];

    if (x + margin > halfX) offsetsX.push(-state.box.x);
    if (x - margin < -halfX) offsetsX.push(state.box.x);
    if (y + margin > halfY) offsetsY.push(-state.box.y);
    if (y - margin < -halfY) offsetsY.push(state.box.y);
    if (z + margin > halfZ) offsetsZ.push(-state.box.z);
    if (z - margin < -halfZ) offsetsZ.push(state.box.z);

    for (const offsetX of offsetsX) {
      for (const offsetY of offsetsY) {
        for (const offsetZ of offsetsZ) {
          if (offsetX === 0 && offsetY === 0 && offsetZ === 0) {
            continue;
          }
          addRenderInstance(i, x + offsetX, y + offsetY, z + offsetZ);
        }
      }
    }
  }
}

function updateInstances(refreshColors = false) {
  const particles = state.particles;
  const visualScale = 1;
  buildRenderInstances(particles, visualScale);
  refreshColors = ensureParticleCapacity(renderInstances.length) || refreshColors;

  particleMesh.count = renderInstances.length;
  let colorsChanged = false;
  for (let i = 0; i < renderInstances.length; i += 1) {
    const instance = renderInstances[i];
    const particleIndex = instance.index;
    const radius = particles.r[particleIndex] * visualScale;
    dummy.position.set(instance.x, instance.y, instance.z);
    dummy.scale.set(radius, radius, radius);
    dummy.updateMatrix();
    particleMesh.setMatrixAt(i, dummy.matrix);
    const colorKey = particles.type[particleIndex];
    if (refreshColors || instanceColorKeys[i] !== colorKey) {
      particleMesh.setColorAt(i, typeColors[colorKey % typeColors.length]);
      instanceColorKeys[i] = colorKey;
      colorsChanged = true;
    }
  }

  particleMesh.instanceMatrix.needsUpdate = true;
  instanceColorKeys.length = renderInstances.length;
  if (colorsChanged && particleMesh.instanceColor) {
    particleMesh.instanceColor.needsUpdate = true;
  }
}

function lognormalPdf(radiusNm, medianRadiusNm, logSigma) {
  if (radiusNm <= 0 || logSigma <= 0) {
    return 0;
  }
  const logRatio = Math.log(radiusNm / medianRadiusNm);
  return Math.exp(-(logRatio * logRatio) / (2 * logSigma * logSigma))
    / (radiusNm * logSigma * Math.sqrt(2 * Math.PI));
}

function drawDistributionChart() {
  const ctx = distributionChart.getContext("2d");
  const scale = window.devicePixelRatio || 1;
  const rect = distributionChart.getBoundingClientRect();
  const width = Math.max(1, Math.floor(rect.width * scale));
  const height = Math.max(1, Math.floor(rect.height * scale));
  if (distributionChart.width !== width || distributionChart.height !== height) {
    distributionChart.width = width;
    distributionChart.height = height;
  }

  const medianRadiusNm = Number(medianRadiusSlider.value);
  const logSigma = Number(logSigmaSlider.value) / 100;
  const maxRadiusNm = Math.max(250, Math.min(2500, medianRadiusNm * Math.exp(3.2 * logSigma)));
  const padding = 24 * scale;
  const samples = 160;
  const values = [];
  let maxPdf = 0;

  for (let i = 0; i < samples; i += 1) {
    const radiusNm = 1 + (maxRadiusNm - 1) * i / (samples - 1);
    const pdf = lognormalPdf(radiusNm, medianRadiusNm, logSigma);
    values.push({ radiusNm, pdf });
    maxPdf = Math.max(maxPdf, pdf);
  }

  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = "rgba(238, 242, 245, 0.16)";
  ctx.lineWidth = scale;
  ctx.beginPath();
  ctx.moveTo(padding, height - padding);
  ctx.lineTo(width - padding * 0.5, height - padding);
  ctx.moveTo(padding, padding * 0.5);
  ctx.lineTo(padding, height - padding);
  ctx.stroke();

  ctx.strokeStyle = "#3b82f6";
  ctx.lineWidth = 2 * scale;
  ctx.beginPath();
  values.forEach((value, index) => {
    const x = padding + (width - padding * 1.5) * index / (samples - 1);
    const y = height - padding - (height - padding * 1.7) * value.pdf / maxPdf;
    if (index === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  });
  ctx.stroke();

  const medianX = padding + (width - padding * 1.5) * (medianRadiusNm - 1) / (maxRadiusNm - 1);
  ctx.strokeStyle = "rgba(34, 197, 94, 0.8)";
  ctx.lineWidth = scale;
  ctx.beginPath();
  ctx.moveTo(medianX, padding * 0.7);
  ctx.lineTo(medianX, height - padding);
  ctx.stroke();

  ctx.fillStyle = "#9fb0bf";
  ctx.font = `${11 * scale}px Inter, sans-serif`;
  ctx.fillText("0", padding, height - 7 * scale);
  ctx.fillText(`${Math.round(maxRadiusNm)} nm`, width - padding * 2.7, height - 7 * scale);
}

function resizeRenderer() {
  const rect = sceneHost.getBoundingClientRect();
  const width = Math.max(1, Math.floor(rect.width));
  const height = Math.max(1, Math.floor(rect.height));
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
}

function render() {
  resizeRenderer();
  controls.update();
  renderer.render(scene, camera);

  frames += 1;
  const now = performance.now();
  if (now - fpsTimestamp >= 1000) {
    renderFpsCounter.textContent = `render ${frames} fps`;
    frames = 0;
    fpsTimestamp = now;
  }

  requestAnimationFrame(render);
}

function setConnection(text) {
  connectionState.textContent = text;
}

function formatCompactCount(value) {
  const count = Number(value);
  if (count >= 1_000_000_000) return `${(count / 1_000_000_000).toFixed(1)}B`;
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(1)}M`;
  if (count >= 10_000) return `${(count / 1_000).toFixed(1)}k`;
  return String(Math.trunc(count));
}

function formatSimulationTime(seconds) {
  if (seconds < 0.001) return `${Math.round(seconds * 1_000_000)}us`;
  if (seconds < 1) return `${(seconds * 1000).toFixed(1)}ms`;
  if (seconds < 100) return `${seconds.toFixed(2)}s`;
  if (seconds < 3600) return `${seconds.toFixed(1)}s`;
  return `${(seconds / 3600).toFixed(2)}h`;
}

function syncControlsFromState() {
  particleCountLabel.textContent = `${state.particleCount} particles`;
  simulationTimeStatus.textContent = `t ${formatSimulationTime(state.time.simulationTime)} steps ${formatCompactCount(state.time.integrationSteps)}`;
  simulationFpsCounter.textContent = `sim ${state.simulationFps} fps`;
  if (state.cpu.available) {
    cpuLoadStatus.textContent = `load app ${state.cpu.processCores.toFixed(1)}c sys ${state.cpu.systemPercent.toFixed(0)}%`;
  } else {
    cpuLoadStatus.textContent = "load n/a";
  }
  const payloadKb = state.transport.payloadBytes / 1024;
  transportStatus.textContent = `io ${payloadKb.toFixed(0)} kB e${state.transport.encodeMs.toFixed(1)} s${state.transport.sendMs.toFixed(1)} step${state.transport.stepMs.toFixed(1)} ms`;
  if (!state.parallel.enabled) {
    parallelStatus.textContent = `cpu serial`;
  } else if (state.parallel.lastStepThreads === 0) {
    parallelStatus.textContent = `cpu idle/${state.parallel.configuredWorkers}`;
  } else if (state.parallel.lastStepItems < state.parallel.minItems) {
    parallelStatus.textContent = `cpu 1/${state.parallel.configuredWorkers} <${state.parallel.minItems}`;
  } else {
    parallelStatus.textContent = `cpu ${state.parallel.lastStepThreads}/${state.parallel.configuredWorkers}`;
  }
  toggleRunningButton.textContent = state.running ? "Pause" : "Start";
  if (![particleSlider, particleNumber].includes(document.activeElement)) {
    particleSlider.value = state.particleCount;
    particleNumber.value = state.particleCount;
    particleValue.textContent = String(state.particleCount);
  }
  if (![boxX, boxY, boxZ].includes(document.activeElement)) {
    boxX.value = Math.round(state.box.x);
    boxY.value = Math.round(state.box.y);
    boxZ.value = Math.round(state.box.z);
  }
  if (dtSlider !== document.activeElement) {
    dtSlider.value = Math.max(1, Math.round(state.time.integrationDt * 1_000_000));
  }
  updateDtLabels();
  dampingToggle.checked = state.forces.dampingEnabled;
  pairInteractionToggle.checked = state.forces.pairInteractionEnabled;
  setPairDependentControlsEnabled(state.forces.pairInteractionEnabled);
  contactModelSelect.value = String(state.forces.contactModel);
  overlapCorrectionToggle.checked = state.forces.overlapCorrectionEnabled;
  if (![pairForceScaleSlider, pairRegularizationSlider, pairCutoffSlider, pairDampingSlider, overlapIterationsSlider, overlapStrengthSlider].includes(document.activeElement)) {
    pairForceScaleSlider.value = Math.round(state.forces.pairForceScale / 0.0001);
    pairRegularizationSlider.value = Math.round(state.forces.pairRegularizationLength * 1000);
    pairCutoffSlider.value = Math.round(state.forces.pairCutoffGap * 1000);
    pairDampingSlider.value = Math.round(state.forces.pairDamping * 1000);
    overlapIterationsSlider.value = state.forces.overlapCorrectionIterations;
    overlapStrengthSlider.value = Math.round(state.forces.overlapCorrectionFraction * 100);
    updatePairInteractionLabels();
  }
  if (![medianRadiusSlider, logSigmaSlider].includes(document.activeElement)) {
    medianRadiusSlider.value = Math.round(state.radiusDistribution.medianRadiusUm * 1000);
    medianRadiusValue.textContent = `${medianRadiusSlider.value} nm`;
    logSigmaSlider.value = Math.round(state.radiusDistribution.logSigma * 100);
    logSigmaValue.textContent = state.radiusDistribution.logSigma.toFixed(2);
    drawDistributionChart();
  }
  fieldToggle.checked = state.forces.constantFieldEnabled;
  collisionToggle.checked = state.collisions.enabled;
  setCollisionDependentControlsEnabled(state.collisions.enabled);
  restitutionSlider.value = Math.round(state.collisions.restitution * 100);
  restitutionValue.textContent = state.collisions.restitution.toFixed(2);
}

function decodeSimulationPayload(rawData) {
  const bytes = rawData instanceof Uint8Array ? rawData : new Uint8Array(rawData);
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const headerSize = view.getUint32(0, true);
  const headerBytes = bytes.subarray(4, 4 + headerSize);
  const data = JSON.parse(new TextDecoder().decode(headerBytes));
  const count = data.particleCount;
  const realBytes = data.binary.realBytes;
  const RealArray = realBytes === 8 ? Float64Array : Float32Array;

  let offset = 4 + headerSize;
  const readArray = (ArrayType, byteLength) => {
    const begin = bytes.byteOffset + offset;
    const end = begin + byteLength;
    offset += byteLength;
    return new ArrayType(bytes.buffer.slice(begin, end));
  };

  const realByteLength = count * realBytes;
  const x = readArray(RealArray, realByteLength);
  const y = readArray(RealArray, realByteLength);
  const z = readArray(RealArray, realByteLength);
  const r = readArray(RealArray, realByteLength);
  const type = readArray(Uint16Array, count * Uint16Array.BYTES_PER_ELEMENT);

  data.particles = { x, y, z, r, type };
  return data;
}

function applySimulationUpdate(rawData) {
  const data = decodeSimulationPayload(rawData);
  const boxChanged = data.box.x !== state.box.x || data.box.y !== state.box.y || data.box.z !== state.box.z;
  const particleCountChanged = data.particleCount !== state.particleCount;
  const refreshColors = particleCountChanged || !data.running;

  state.running = data.running;
  state.box = data.box;
  state.particleCount = data.particleCount;
  state.simulationFps = data.simulationFps;
  state.timeScale = data.timeScale;
  state.time = data.time;
  state.cpu = data.cpu;
  state.transport = data.transport;
  state.parallel = data.parallel;
  state.particles = data.particles;
  state.radiusDistribution = data.radiusDistribution;
  state.forces = data.forces;
  state.collisions = data.collisions;

  if (boxChanged) {
    updateBox();
  }
  updateInstances(refreshColors);
  syncControlsFromState();
}

function simulationUpdate(rawData) {
  applySimulationUpdate(rawData);
}

globalThis.simulationUpdate = simulationUpdate;

async function setRunning(running) {
  if (typeof webui === "undefined") return;
  const response = await webui.setRunningB(running);
  state.running = Boolean(Number(response));
  toggleRunningButton.textContent = state.running ? "Pause" : "Start";
}

async function setParticleCount(value) {
  const count = Number(value);
  particleValue.textContent = String(count);
  if (typeof webui === "undefined") return;
  const accepted = await webui.setParticleCountB(count);
  particleSlider.value = accepted;
  particleNumber.value = accepted;
  particleValue.textContent = accepted;
}

async function resetSimulation() {
  if (typeof webui === "undefined") return;
  await webui.resetSimulationB();
}

function orientCameraPerpendicularToCollisionAxis() {
  const distance = Math.max(controls.minDistance, camera.position.distanceTo(controls.target));
  controls.target.set(0, 0, 0);
  camera.up.set(0, 1, 0);
  camera.position.set(0, 0, distance);
  camera.lookAt(controls.target);
  controls.update();
}

async function twoParticleTest() {
  if (typeof webui === "undefined") return;
  const acceptedDistance = await webui.twoParticleTestB(Number(twoParticleDistance.value));
  twoParticleDistance.value = acceptedDistance;
  orientCameraPerpendicularToCollisionAxis();
}

function formatDt(seconds) {
  const microseconds = seconds * 1_000_000;
  if (microseconds < 1000) {
    return `${Math.round(microseconds)} us`;
  }
  return `${(microseconds / 1000).toFixed(2)} ms`;
}

function getMinimumParticleRadius() {
  let minRadius = state.radiusDistribution.medianRadiusUm;
  if (state.particles.r.length > 0) {
    minRadius = Number.POSITIVE_INFINITY;
    for (const radius of state.particles.r) {
      minRadius = Math.min(minRadius, radius);
    }
  }
  return minRadius;
}

function estimateStableDtLimit() {
  if (!state.forces.pairInteractionEnabled) {
    return null;
  }

  const minRadius = getMinimumParticleRadius();
  const mass = Math.max(0.01, minRadius * minRadius * minRadius);
  const reducedMass = mass * 0.5;
  const ell = Math.max(1e-6, Number(pairRegularizationSlider.value) / 1000);
  const forceScale = Math.max(1e-12, Number(pairForceScaleSlider.value) * 0.0001);
  const stiffness = Math.max(1e-12, forceScale / (ell * ell * ell));
  return 0.075 * Math.sqrt(reducedMass / stiffness);
}

function estimateCutoffStepDisplacement() {
  if (!state.forces.pairInteractionEnabled) {
    return null;
  }

  const minRadius = getMinimumParticleRadius();
  if (!(minRadius > 0)) {
    return null;
  }

  const cutoff = Math.max(1e-6, Number(pairCutoffSlider.value) / 1000);
  const ell = Math.max(1e-6, Number(pairRegularizationSlider.value) / 1000);
  const forceScale = Math.max(0, Number(pairForceScaleSlider.value) * 0.0001);
  const forceAtCutoff = forceScale * cutoff * cutoff / (cutoff * cutoff * cutoff + ell * ell * ell);
  const mass = Math.max(0.01, minRadius * minRadius * minRadius);
  const integrationDt = Number(dtSlider.value) / 1_000_000;
  return 0.5 * forceAtCutoff / mass * integrationDt * integrationDt;
}

function formatNanometers(valueUm) {
  const valueNm = valueUm * 1000;
  if (valueNm < 0.01) return `${valueNm.toFixed(4)} nm`;
  if (valueNm < 1) return `${valueNm.toFixed(3)} nm`;
  if (valueNm < 100) return `${valueNm.toFixed(2)} nm`;
  return `${valueNm.toFixed(1)} nm`;
}

function updateCutoffStepStatus() {
  const displacement = estimateCutoffStepDisplacement();
  cutoffStepStatus.classList.remove("stable", "borderline", "too-large", "disabled");
  if (displacement === null) {
    cutoffStepStatus.classList.add("disabled");
    cutoffStepStatus.textContent = "cutoff n/a";
    return;
  }

  const displacementNm = displacement * 1000;
  if (displacementNm < 0.001 || displacementNm > 1) {
    cutoffStepStatus.classList.add("too-large");
  } else if (displacementNm < 0.01 || displacementNm > 0.1) {
    cutoffStepStatus.classList.add("borderline");
  } else {
    cutoffStepStatus.classList.add("stable");
  }
  cutoffStepStatus.textContent = `cutoff dx ${formatNanometers(displacement)}`;
}

function updateDtLabels() {
  const integrationDt = Number(dtSlider.value) / 1_000_000;
  dtValue.textContent = formatDt(integrationDt);

  const stableLimit = estimateStableDtLimit();
  stabilityStatus.className = "stability-status";
  if (stableLimit === null) {
    stabilityStatus.classList.add("disabled");
    stabilityStatus.textContent = `stability n/a`;
  } else if (integrationDt <= stableLimit) {
    stabilityStatus.classList.add("stable");
    stabilityStatus.textContent = `stable <= ${formatDt(stableLimit)}`;
  } else if (integrationDt <= stableLimit * 2) {
    stabilityStatus.classList.add("borderline");
    stabilityStatus.textContent = `borderline <= ${formatDt(stableLimit)}`;
  } else {
    stabilityStatus.classList.add("too-large");
    stabilityStatus.textContent = `too large > ${formatDt(stableLimit)}`;
  }
  updateCutoffStepStatus();
}

async function setIntegrationDt(value) {
  const requestedUs = Number(value);
  dtSlider.value = requestedUs;
  updateDtLabels();
  if (typeof webui === "undefined") return;
  const acceptedUs = await webui.setIntegrationDtB(requestedUs);
  dtSlider.value = acceptedUs;
  updateDtLabels();
}

async function setBox() {
  if (typeof webui === "undefined") return;
  const response = await webui.setBoxB(Number(boxX.value), Number(boxY.value), Number(boxZ.value));
  const [x, y, z] = response.split(";").map(Number);
  boxX.value = x;
  boxY.value = y;
  boxZ.value = z;
}

function updateDistributionLabels() {
  medianRadiusValue.textContent = `${medianRadiusSlider.value} nm`;
  logSigmaValue.textContent = (Number(logSigmaSlider.value) / 100).toFixed(2);
  drawDistributionChart();
}

async function setRadiusDistribution() {
  updateDistributionLabels();
  if (typeof webui === "undefined") return;
  const response = await webui.setRadiusDistributionB(
    Number(medianRadiusSlider.value),
    Number(logSigmaSlider.value)
  );
  const [medianRadiusNm, logSigmaPercent] = response.split(";").map(Number);
  medianRadiusSlider.value = medianRadiusNm;
  logSigmaSlider.value = logSigmaPercent;
  updateDistributionLabels();
}

function updatePairInteractionLabels() {
  pairForceScaleValue.textContent = pairForceScaleSlider.value;
  pairRegularizationValue.textContent = `${pairRegularizationSlider.value} nm`;
  pairCutoffValue.textContent = `${pairCutoffSlider.value} nm`;
  pairDampingValue.textContent = (Number(pairDampingSlider.value) / 1000).toFixed(3);
  overlapIterationsValue.textContent = overlapIterationsSlider.value;
  overlapStrengthValue.textContent = `${overlapStrengthSlider.value}%`;
  updateCutoffStepStatus();
}

function setPairDependentControlsEnabled(enabled) {
  document.querySelectorAll(".pair-dependent-control").forEach((control) => {
    control.classList.toggle("disabled-control", !enabled);
    control.querySelectorAll("input, select, button").forEach((element) => {
      element.disabled = !enabled;
    });
  });
}

function setCollisionDependentControlsEnabled(enabled) {
  document.querySelectorAll(".collision-dependent-control").forEach((control) => {
    control.classList.toggle("disabled-control", !enabled);
    control.querySelectorAll("input, select, button").forEach((element) => {
      element.disabled = !enabled;
    });
  });
}

async function setPairInteractionParams() {
  updatePairInteractionLabels();
  if (typeof webui === "undefined") return;
  const response = await webui.setPairInteractionParamsB(
    Number(pairForceScaleSlider.value),
    Number(pairRegularizationSlider.value),
    Number(pairCutoffSlider.value),
    Number(pairDampingSlider.value),
    Number(overlapIterationsSlider.value),
    Number(overlapStrengthSlider.value)
  );
  const [forceScaleUnits, regularizationNm, cutoffNm, dampingUnits, correctionIterations, correctionPercent] = response.split(";").map(Number);
  pairForceScaleSlider.value = forceScaleUnits;
  pairRegularizationSlider.value = regularizationNm;
  pairCutoffSlider.value = cutoffNm;
  pairDampingSlider.value = dampingUnits;
  overlapIterationsSlider.value = correctionIterations;
  overlapStrengthSlider.value = correctionPercent;
  updatePairInteractionLabels();
}

async function setContactModel(value) {
  if (typeof webui === "undefined") return;
  const accepted = await webui.setContactModelB(Number(value));
  contactModelSelect.value = String(accepted);
}

function queueRadiusDistributionUpdate() {
  updateDistributionLabels();
  window.clearTimeout(distributionUpdateTimer);
  distributionUpdateTimer = window.setTimeout(setRadiusDistribution, 160);
}

function queuePairInteractionUpdate() {
  updatePairInteractionLabels();
  updateDtLabels();
  window.clearTimeout(pairInteractionUpdateTimer);
  pairInteractionUpdateTimer = window.setTimeout(setPairInteractionParams, 160);
}

async function setToggle(callbackName, element) {
  if (typeof webui === "undefined") return;
  const response = await webui[callbackName](element.checked);
  element.checked = Boolean(Number(response));
}

async function setRestitution(value) {
  const percent = Number(value);
  restitutionValue.textContent = (percent / 100).toFixed(2);
  if (typeof webui === "undefined") return;
  const accepted = await webui.setRestitutionB(percent);
  restitutionSlider.value = accepted;
  restitutionValue.textContent = (Number(accepted) / 100).toFixed(2);
}

toggleRunningButton.addEventListener("click", () => setRunning(!state.running));
resetButton.addEventListener("click", resetSimulation);
twoParticleTestButton.addEventListener("click", twoParticleTest);

particleSlider.addEventListener("input", (event) => {
  particleValue.textContent = event.target.value;
  particleNumber.value = event.target.value;
});
particleSlider.addEventListener("change", (event) => setParticleCount(event.target.value));
particleNumber.addEventListener("input", (event) => {
  particleValue.textContent = event.target.value;
  particleSlider.value = event.target.value;
});
particleNumber.addEventListener("change", (event) => setParticleCount(event.target.value));
dtSlider.addEventListener("input", (event) => setIntegrationDt(event.target.value));
boxX.addEventListener("change", setBox);
boxY.addEventListener("change", setBox);
boxZ.addEventListener("change", setBox);
medianRadiusSlider.addEventListener("input", queueRadiusDistributionUpdate);
logSigmaSlider.addEventListener("input", queueRadiusDistributionUpdate);
dampingToggle.addEventListener("change", () => setToggle("setDampingEnabledB", dampingToggle));
fieldToggle.addEventListener("change", () => setToggle("setConstantFieldEnabledB", fieldToggle));
pairInteractionToggle.addEventListener("change", async () => {
  await setToggle("setPairInteractionEnabledB", pairInteractionToggle);
  state.forces.pairInteractionEnabled = pairInteractionToggle.checked;
  setPairDependentControlsEnabled(pairInteractionToggle.checked);
  updateDtLabels();
});
contactModelSelect.addEventListener("change", (event) => setContactModel(event.target.value));
overlapCorrectionToggle.addEventListener("change", () => setToggle("setOverlapCorrectionEnabledB", overlapCorrectionToggle));
pairForceScaleSlider.addEventListener("input", queuePairInteractionUpdate);
pairRegularizationSlider.addEventListener("input", queuePairInteractionUpdate);
pairCutoffSlider.addEventListener("input", queuePairInteractionUpdate);
pairDampingSlider.addEventListener("input", queuePairInteractionUpdate);
overlapIterationsSlider.addEventListener("input", queuePairInteractionUpdate);
overlapStrengthSlider.addEventListener("input", queuePairInteractionUpdate);
collisionToggle.addEventListener("change", async () => {
  await setToggle("setCollisionsEnabledB", collisionToggle);
  state.collisions.enabled = collisionToggle.checked;
  setCollisionDependentControlsEnabled(collisionToggle.checked);
});
restitutionSlider.addEventListener("input", (event) => setRestitution(event.target.value));
boxToggle.addEventListener("change", () => {
  boxHelper.visible = boxToggle.checked;
});
axisLabelsToggle.addEventListener("change", () => {
  axisLabels.visible = axisLabelsToggle.checked;
});
gridToggle.addEventListener("change", () => {
  gridGroup.visible = gridToggle.checked;
});
periodicImagesToggle.addEventListener("change", () => {
  updateInstances();
});
particleClipToggle.addEventListener("change", () => {
  updateParticleClipping();
});
resetViewButton.addEventListener("click", resetView);

const tooltipBubble = document.createElement("div");
tooltipBubble.className = "tooltip-bubble";
document.body.appendChild(tooltipBubble);

function positionTooltip(anchor) {
  const text = anchor.dataset.tooltip;
  if (!text) return;
  tooltipBubble.textContent = text;
  tooltipBubble.classList.add("visible");

  const anchorRect = anchor.getBoundingClientRect();
  const bubbleRect = tooltipBubble.getBoundingClientRect();
  const margin = 8;
  let left = anchorRect.left + anchorRect.width * 0.5 - bubbleRect.width * 0.5;
  left = Math.max(margin, Math.min(window.innerWidth - bubbleRect.width - margin, left));

  let top = anchorRect.top - bubbleRect.height - margin;
  if (top < margin) {
    top = anchorRect.bottom + margin;
  }
  top = Math.max(margin, Math.min(window.innerHeight - bubbleRect.height - margin, top));

  tooltipBubble.style.left = `${left}px`;
  tooltipBubble.style.top = `${top}px`;
}

function hideTooltip() {
  tooltipBubble.classList.remove("visible");
}

document.querySelectorAll(".hint").forEach((hint) => {
  hint.addEventListener("mouseenter", () => positionTooltip(hint));
  hint.addEventListener("focus", () => positionTooltip(hint));
  hint.addEventListener("mouseleave", hideTooltip);
  hint.addEventListener("blur", hideTooltip);
});
window.addEventListener("scroll", hideTooltip, true);
window.addEventListener("resize", hideTooltip);

document.addEventListener("DOMContentLoaded", () => {
  if (typeof webui !== "undefined") {
    webui.setEventCallback((event) => {
      if (event === webui.event.CONNECTED) {
        setConnection("Connected");
      } else if (event === webui.event.DISCONNECTED) {
        setConnection("Disconnected");
      }
    });
  } else {
    setConnection("webui.js missing");
  }
});

updateBox();
updateParticleClipping();
updateDistributionLabels();
updateDtLabels();
setPairDependentControlsEnabled(pairInteractionToggle.checked);
setCollisionDependentControlsEnabled(collisionToggle.checked);
ensureParticleCapacity(1);
requestAnimationFrame(render);
