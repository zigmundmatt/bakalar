#pragma once

#include "simulation.hpp"
#include "webui.hpp"

#include <deque>
#include <cstddef>
#include <mutex>
#include <string>
#include <thread>
#include <variant>

using SimulationCommand = std::variant<
    AddParticlesCommand,
    RemoveParticlesCommand,
    SetRunningCommand,
    SetParticleCountCommand,
    SetTimeScaleCommand,
    SetBoxCommand,
    RegenerateParticlesCommand,
    ConfigureTwoParticleTestCommand,
    SetRadiusDistributionCommand,
    SetDampingEnabledCommand,
    SetConstantFieldEnabledCommand,
    SetPairInteractionEnabledCommand,
    SetPairInteractionParamsCommand,
    SetOverlapCorrectionEnabledCommand,
    SetContactModelCommand,
    SetCollisionsEnabledCommand,
    SetRestitutionCommand>;

class App
{
public:
    App();
    void run(bool serverMode);

private:
    webui::window window_;
    Simulation simulation_;
    std::mutex simulationMutex_;
    std::deque<SimulationCommand> commands_;
    std::mutex commandsMutex_;
    int simulationFps_ = 0;
    double processCpuPercent_ = 0.0;
    double processCpuCores_ = 0.0;
    double systemCpuPercent_ = 0.0;
    std::size_t uiPayloadBytes_ = 0;
    double uiEncodeMs_ = 0.0;
    double uiSendMs_ = 0.0;
    double simulationStepMs_ = 0.0;
    bool cpuTelemetryAvailable_ = false;

    void enqueue(SimulationCommand command);
    void applyPendingCommands();
    std::string simulationPayload() const;
    void simulationLoop(std::stop_token stopToken);
    void uiLoop(std::stop_token stopToken);

    void setRunningB(webui::window::event* e);
    void resetSimulationB(webui::window::event* e);
    void twoParticleTestB(webui::window::event* e);
    void setParticleCountB(webui::window::event* e);
    void addParticlesB(webui::window::event* e);
    void removeParticlesB(webui::window::event* e);
    void setIntegrationDtB(webui::window::event* e);
    void setBoxB(webui::window::event* e);
    void setRadiusDistributionB(webui::window::event* e);
    void setDampingEnabledB(webui::window::event* e);
    void setConstantFieldEnabledB(webui::window::event* e);
    void setPairInteractionEnabledB(webui::window::event* e);
    void setPairInteractionParamsB(webui::window::event* e);
    void setOverlapCorrectionEnabledB(webui::window::event* e);
    void setContactModelB(webui::window::event* e);
    void setCollisionsEnabledB(webui::window::event* e);
    void setRestitutionB(webui::window::event* e);
};
