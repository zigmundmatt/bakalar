#pragma once

#include <algorithm>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <random>
#include <string>
#include <thread>
#include <vector>

#if defined(PARTICLE_REAL_TYPE_double)
using Real = double;
#else
using Real = float;
#endif

inline constexpr int kPhysicsSubsteps = 4;

enum class ContactModel : std::uint8_t
{
    Quadratic = 0,
    Linear = 1,
    Hertz = 2
};

#ifndef PARTICLE_ENABLE_PARALLEL
#define PARTICLE_ENABLE_PARALLEL 0
#endif

#ifndef PARTICLE_PARALLEL_MIN_ITEMS
#define PARTICLE_PARALLEL_MIN_ITEMS 256
#endif

struct Vec3
{
    Real x = Real{0};
    Real y = Real{0};
    Real z = Real{0};
};

struct Box
{
    Vec3 size{Real{10}, Real{10}, Real{10}};
};

struct ParticleStore
{
    std::vector<std::uint32_t> id;
    std::vector<Real> x;
    std::vector<Real> y;
    std::vector<Real> z;
    std::vector<Real> vx;
    std::vector<Real> vy;
    std::vector<Real> vz;
    std::vector<Real> fx;
    std::vector<Real> fy;
    std::vector<Real> fz;
    std::vector<Real> radius;
    std::vector<Real> mass;
    std::vector<std::uint16_t> type;

    [[nodiscard]] std::size_t size() const;
    void clear();
    void reserve(std::size_t count);
    void eraseSwap(std::size_t index);
};

struct ForceConfig
{
    bool dampingEnabled = false;
    Real damping = Real{0.08};
    bool constantFieldEnabled = false;
    Vec3 constantAcceleration{Real{0}, Real{-0.35}, Real{0}};
    bool pairInteractionEnabled = true;
    Real pairForceScale = Real{0.0005};
    Real pairRegularizationLength = Real{0.05};
    Real pairCutoffGap = Real{0.5};
    Real pairDamping = Real{0.02};
    ContactModel contactModel = ContactModel::Quadratic;
    bool overlapCorrectionEnabled = false;
    int overlapCorrectionIterations = 4;
    Real overlapCorrectionFraction = Real{0.45};
};

struct CollisionConfig
{
    bool enabled = false;
    Real restitution = Real{1};
};

struct RadiusDistributionConfig
{
    Real medianRadiusUm = Real{0.1};
    Real logSigma = Real{0.35};
};

struct SimulationConfig
{
    bool running = false;
    Real timeScale = Real{1};
    Box box;
    RadiusDistributionConfig radiusDistribution;
    ForceConfig forces;
    CollisionConfig collisions;
};

struct SimulationSnapshot
{
    SimulationConfig config;
    const ParticleStore* particles = nullptr;
    double simulationTime = 0.0;
    std::uint64_t integrationSteps = 0;
};

struct ParallelStats
{
    bool enabled = PARTICLE_ENABLE_PARALLEL != 0;
    unsigned int hardwareThreads = 1;
    unsigned int configuredWorkers = 1;
    unsigned int lastStepThreads = 0;
    std::size_t lastStepItems = 0;
    std::size_t minItems = PARTICLE_PARALLEL_MIN_ITEMS;
};

struct AddParticlesCommand
{
    int count = 1;
};

struct RemoveParticlesCommand
{
    int count = 1;
};

struct SetRunningCommand
{
    bool running = true;
};

struct SetParticleCountCommand
{
    int count = 1;
};

struct SetTimeScaleCommand
{
    Real timeScale = Real{1};
};

struct SetBoxCommand
{
    Box box;
};

struct RegenerateParticlesCommand
{
};

struct ConfigureTwoParticleTestCommand
{
    Real surfaceGap = Real{0.5};
};

struct SetRadiusDistributionCommand
{
    RadiusDistributionConfig distribution;
};

struct SetDampingEnabledCommand
{
    bool enabled = false;
};

struct SetConstantFieldEnabledCommand
{
    bool enabled = false;
};

struct SetPairInteractionEnabledCommand
{
    bool enabled = false;
};

struct SetPairInteractionParamsCommand
{
    Real forceScale = Real{0.0005};
    Real regularizationLength = Real{0.05};
    Real cutoffGap = Real{0.5};
    Real damping = Real{0.02};
    int overlapCorrectionIterations = 4;
    Real overlapCorrectionFraction = Real{0.45};
};

struct SetOverlapCorrectionEnabledCommand
{
    bool enabled = true;
};

struct SetContactModelCommand
{
    ContactModel model = ContactModel::Quadratic;
};

struct SetCollisionsEnabledCommand
{
    bool enabled = false;
};

struct SetRestitutionCommand
{
    Real restitution = Real{1};
};

class Simulation
{
public:
    explicit Simulation(std::uint32_t seed = std::random_device{}());
    ~Simulation();

    void reset(int particleCount);
    void step(Real dt);

    void apply(const AddParticlesCommand& command);
    void apply(const RemoveParticlesCommand& command);
    void apply(const SetRunningCommand& command);
    void apply(const SetParticleCountCommand& command);
    void apply(const SetTimeScaleCommand& command);
    void apply(const SetBoxCommand& command);
    void apply(const RegenerateParticlesCommand& command);
    void apply(const ConfigureTwoParticleTestCommand& command);
    void apply(const SetRadiusDistributionCommand& command);
    void apply(const SetDampingEnabledCommand& command);
    void apply(const SetConstantFieldEnabledCommand& command);
    void apply(const SetPairInteractionEnabledCommand& command);
    void apply(const SetPairInteractionParamsCommand& command);
    void apply(const SetOverlapCorrectionEnabledCommand& command);
    void apply(const SetContactModelCommand& command);
    void apply(const SetCollisionsEnabledCommand& command);
    void apply(const SetRestitutionCommand& command);

    [[nodiscard]] int particleCount() const;
    [[nodiscard]] SimulationSnapshot snapshot() const;
    [[nodiscard]] ParallelStats parallelStats() const;

private:
    SimulationConfig config_;
    ParticleStore particles_;
    double simulationTime_ = 0.0;
    std::uint64_t integrationSteps_ = 0;
    std::mt19937 rng_;
    std::uint32_t nextId_ = 1;
    unsigned int workerCount_ = std::max(1U, std::thread::hardware_concurrency());
    unsigned int currentStepThreads_ = 0;
    unsigned int lastStepThreads_ = 0;
    std::size_t lastStepItems_ = 0;
    std::vector<std::jthread> workers_;
    std::mutex workerMutex_;
    std::condition_variable_any workerCv_;
    std::condition_variable workerDoneCv_;
    std::function<void(std::size_t, std::size_t)> workerTask_;
    std::size_t workerTaskItems_ = 0;
    std::size_t workerBlockSize_ = 0;
    std::size_t workerTaskThreads_ = 0;
    std::size_t remainingWorkers_ = 0;
    std::uint64_t workerGeneration_ = 0;

    void addParticles(int count);
    void removeParticles(int count);
    void addParticle(Vec3 position, Real radius, std::uint16_t type);
    void configureTwoParticleTest(Real surfaceGap);
    void startWorkers();
    void workerLoop(std::stop_token stopToken, std::size_t workerIndex);
    template <typename Function>
    void parallelFor(std::size_t count, Function&& function);
    template <typename Function>
    void parallelForIndexed(std::size_t count, Function&& function);
    void clearForces();
    void applyForces();
    void applyPairInteractionForces();
    void resolveOverlaps();
    void resolveImpulseCollisions();
    void integrate(Real dt);
    void wrapPosition(std::size_t index);
};
