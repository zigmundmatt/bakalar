# Vizualizace částicové dynamiky v Hamakerově modelu interakce

## Motivace

Při zkoumání chování nanočástic nad sublimačním rozhraním byla pozorována jejich samoorganizace do agregátů s vysokým specifickým povrchem (SSA), které vykazovaly dobrou fotokatalytickou aktivitu [1]. Na základě těchto poznatků byla vyvinuta nová technologie přípravy a modifikace speciálních nanomateriálů s vysokým SSA, který se pohybuje v řádu stovek m²/g ve srovnání s jednotkami m²/g u stejného částicového materiálu získaného standardní metodou tepelného sušení [1], [2]. Přestože byla tato technologie patentově chráněna [3], samotný patent nepokrývá všechny podstatné aspekty know-how potřebné pro optimální aplikace. Vzhledem k rozmanitosti disperzních materiálů je proto třeba fyzikálně-chemické principy procesu řízené vakuové sublimace podrobněji objasnit.

![1775745361693](image/README/1775745361693.png)

Obrázek 1: Fotografie lamelárních agregátů nC60 unášených sublimačním proudem (vlevo) a TEM snímek této struktury s viditelnými trhlinami způsobenými tlakem sublimačního proudění.

Na konečnou vazbu mezi dvěma nanočásticemi mají zásadní vliv zejména rychlost částic v okamžiku srážky, vazebná energie mezi agregovanými částicemi a také mezifázové jevy v okolí částic, zejména vliv mezifázového napětí a ζ-potenciálu [4]. Popsat tyto děje čistě experimentálně je obtížné, proto je vhodné doplnit výzkum numerickým modelováním, které umožní studovat dynamiku částic za definovaných podmínek a systematicky sledovat vliv jednotlivých parametrů na vznik výsledných struktur.

## Zadání

Cílem práce je navrhnout a implementovat prototyp softwarového nástroje pro interaktivní 3D vizualizaci částicové dynamiky v konečném periodickém boxu. Fyzikální motivací je agregace nanočástic při řízené vakuové lyofilizaci a Hamakerův model interakce [5], vlastní práce se však soustředí především na softwarovou architekturu, reprezentaci částicového systému, základní časový vývoj a 3D vizualizaci.

Práce nemá primárně usilovat o úplný fyzikálně-chemický popis procesu lyofilizace. Podstatné je vytvořit rozšiřitelný software, do kterého lze později doplňovat různé silové modely, okrajové podmínky a vizualizační režimy. V základním rozsahu je proto přijatelné pracovat s jednoduchým demonstračním silovým polem nebo volným pohybem částic. Hamakerova interakce může být popsána jako cílový model a podle časových možností implementována ve zjednodušené podobě.

![1775746238961](image/README/1775746238961.png)

Obrázek 2: Schéma postupné akumulace částic na sublimačním rozhraní během jeho ústupu vlivem odpařování rozpouštědla do vakua (vlevo) [4] a příklad dvourozměrného matematického modelování nanostrukturních destiček (vpravo).

V rámci práce bude vytvořen programový nástroj pro práci s částicemi ve 3D prostoru, doplněný o interaktivní vizualizaci. Backend bude zajišťovat stav systému, základní numerický krok, periodické okrajové podmínky a přípravu dat pro frontend. Frontend bude poskytovat ovládání základních parametrů, 3D scénu, kameru a zobrazení částic.

Z hlediska backendu bude práce řešit zejména reprezentaci částic, volbu jednoduchého časového kroku a práci s periodickým boxem. Student by měl popsat, jak zvolená velikost časového kroku ovlivňuje plynulost a stabilitu vizualizace a jak jsou částice vraceny do reprezentativní výpočetní domény. Složitější problémy, jako přesná detekce kolizí, řešení překryvů částic, omezení nežádoucích přeskoků při silných interakcích nebo prostorové datové struktury pro hledání sousedů, budou chápány jako rozšiřující témata.

Z hlediska frontendu bude práce řešit výběr vhodného technologického základu pro uživatelské rozhraní a 3D vykreslování. Student by měl stručně porovnat několik možných přístupů a zdůvodnit zvolenou cestu s ohledem na interaktivitu, přenositelnost, jednoduchost distribuce a napojení na výpočetní backend. Důležitou součástí bude návrh ovládacích prvků pro parametry výpočtu, práce s kamerou, měřítkem scény a průběžnou aktualizací dat.

Přínosem práce bude především ověřený softwarový návrh a funkční prototyp vizualizačního nástroje pro částicové systémy. Výsledek má vytvořit základ, na který lze v dalších pracích navázat přesnějším fyzikálním modelem, analýzou agregace nebo porovnáním s experimenty z oblasti řízené vakuové lyofilizace.

## Doporučené dílčí body řešení

1. Seznámit se s aplikační motivací částicové dynamiky při řízené vakuové lyofilizaci a s významem Hamakerovy interakce jako jednoho z možných silových modelů.
2. Navrhnout architekturu aplikace oddělující výpočetní backend, přenos dat a vizualizační frontend.
3. Navrhnout datový model částic, výpočetní domény a stavů simulace tak, aby byl později rozšiřitelný o další síly, okrajové podmínky a agregační pravidla.
4. Zvolit a zdůvodnit jednoduchý numerický způsob časového vývoje částic.
5. Navrhnout reprezentaci periodického boxu a způsob zobrazení částic ve 3D scéně.
6. Stručně porovnat vhodné technologie pro GUI a 3D vizualizaci a vybrat řešení odpovídající rozsahu práce.
7. Implementovat interaktivní prototyp umožňující spouštění, zastavení a reset výpočtu, změnu základních parametrů a plynulé zobrazení částic ve 3D scéně.
8. Připravit základní testovací a demonstrační scénáře pro ověření funkčnosti backendu a použitelnosti vizualizace.
9. Zhodnotit omezení vytvořeného prototypu a navrhnout další kroky směrem k přesnějšímu fyzikálnímu modelu a analýze agregace.

## Předpokládané výstupy práce

- návrh architektury aplikace pro částicovou dynamiku a její 3D vizualizaci,
- funkční prototyp backendu pro správu částic, časový vývoj a okrajové podmínky,
- interaktivní 3D vizualizace časového vývoje částicového systému,
- zdůvodněná volba GUI a 3D vizualizační technologie,
- základní sada testovacích a demonstračních scénářů,
- popis omezení prototypu a doporučení pro navazující fyzikální nebo numerické rozšíření.

## Možná rozšíření tématu

- prostorové datové struktury pro efektivní hledání sousedů, například uniformní mřížka nebo cell list,
- porovnání různých integračních schémat z hlediska stability, přesnosti a rychlosti,
- ukládání a načítání konfigurací simulace ve strukturovaném formátu,
- export snímků nebo časových řad pro pozdější analýzu,
- měření výkonu backendu a frontendu při rostoucím počtu částic,
- vizualizační vrstvy pro rychlost, sílu, trajektorie, kontakty nebo shluky částic,
- základní validační scénáře, například zachování periodických podmínek, reprodukovatelnost po resetu se stejným seedem nebo detekce překryvů.

## Reference

[1] R. Dvorský, "Preparation of high-performance photocatalytic core-shell lamellar nanostructures ZnO-(Si)-ZnO with high specific surface area," *Advanced Materials Letters*, vol. 7, no. 9, pp. 730-734, 2016, doi: 10.5185/amlett.2016.6380.

[2] J. Bednář et al., "Antimicrobial synergistic effect between Ag and Zn in Ag-ZnO.mSiO2 silicate composite with high specific surface area," *Nanomaterials*, vol. 9, no. 9, Art. no. 1265, 2019, doi: 10.3390/nano9091265.

[3] R. Dvorský, "Method of the preparation of fibrillar and lamellar porous microstructures and nanostructures by means of controlled vacuum freeze-drying of liquid nanoparticles dispersions," patent family including CZ 303513 B6, US 9,410,739 B2, JP 5961266 B2, CN 103842755 B, RU 2599282 C2, and EP 2751508 B1.

[4] D. Krpelík, R. Dvorský, P. Mančík, J. Bednář, and L. Svoboda, "Mathematical modelling of lamellar aggregation of dispersed globular nanoparticles nC60 on the interface upon sublimation of water molecules from rapid frozen dispersion," *Journal of Nanoscience and Nanotechnology*, vol. 19, no. 5, pp. 2671-2677, 2019, doi: 10.1166/jnn.2019.15856.

[5] H. C. Hamaker, "The London-van der Waals attraction between spherical particles," *Physica*, vol. 4, no. 10, pp. 1058-1072, 1937, doi: 10.1016/S0031-8914(37)80203-7.

## Doporučená literatura

1. I. Nezbeda, J. Kolafa, and M. Kotrla, *Úvod do počítačových simulací: metody Monte Carlo a molekulární dynamiky*. Praha: Karolinum, 2003. ISBN 80-246-0649-6.
2. M. P. Allen and D. J. Tildesley, *Computer Simulation of Liquids*, 2nd ed. Oxford: Oxford University Press, 2017. ISBN 978-0-19-880319-5.
3. D. Frenkel and B. Smit, *Understanding Molecular Simulation: From Algorithms to Applications*, 2nd ed. San Diego: Academic Press, 2002. ISBN 978-0-12-267351-1.
4. D. C. Rapaport, *The Art of Molecular Dynamics Simulation*, 2nd ed. Cambridge: Cambridge University Press, 2004. ISBN 978-0-521-82568-9.
5. D. H. Eberly, *3D Game Engine Design: A Practical Approach to Real-Time Computer Graphics*, 2nd ed. Boca Raton: CRC Press, 2006. ISBN 978-0-12-229063-3.
6. E. Lengyel, *Mathematics for 3D Game Programming and Computer Graphics*, 3rd ed. Boston: Cengage Learning, 2012. ISBN 978-1-4354-5886-4.
7. E. Gamma, R. Helm, R. Johnson, and J. Vlissides, *Design Patterns: Elements of Reusable Object-Oriented Software*. Boston: Addison-Wesley, 1994. ISBN 978-0-201-63361-0.
8. R. C. Martin, *Clean Architecture: A Craftsman's Guide to Software Structure and Design*. Boston: Prentice Hall, 2017. ISBN 978-0-13-449416-6.
9. S.-Y. Ha, J. Kim, P. Kuchling, and O. Kutovyi, "Infinite particle systems with collective behaviour and related mesoscopic equations," *Journal of Mathematical Physics*, vol. 60, no. 12, 122704, 2019, doi: 10.1063/1.5095487.

# Program example

![1781810974399](image/README/1781810974399.png)

Small C++26/WebUI application for visualizing particles in a periodic 3D box.

The C++ backend owns the simulation state and streams compact binary snapshots with a small JSON header to the embedded UI with `send_raw`. The frontend is a local `ui/` folder, embedded into the binary through WebUI's virtual file system generator.

## Current Scope

- free particles moving in a SoA-based simulation core,
- periodic boundary conditions in a rectangular 3D domain with micrometer units,
- particle count, pause/start, reset, box size, and explicit integration time-step controls,
- log-normal particle-radius distribution controlled in nanometers from the UI,
- optional multithreaded CPU loops for force clearing, external forces, pair forces, overlap correction, and integration,
- optional damping and constant-field force toggles,
- simplified pair interaction enabled by default, with selectable contact model and optional position-only overlap correction disabled by default,
- collision settings for an independent impulse-collision velocity solver with configurable restitution,
- UI status counters for simulation FPS, render FPS, CPU usage, transport cost, active worker threads, and time-step stability estimate,
- Three.js `InstancedMesh` rendering with orbit and zoom controls,
- vendored frontend dependencies and no UI submodule.

This version is intended to establish the scalable application shape for thousands of particles while keeping the physical model intentionally simple and adjustable.

## Time stepping

The simulation advances with a fixed frame step split into physics substeps:

```math
\Delta t_\text{frame} = \frac{1}{120}\ \mathrm{s}, \qquad
N_\text{substeps} = 4.
```

The actual integration step shown in the UI is

```math
\Delta t_\text{int} = \frac{\Delta t_\text{frame}}{N_\text{substeps}} \cdot s,
```

where `s` is the internal time-scale factor. The default value is

```math
\Delta t_\text{int} = \frac{1}{480}\ \mathrm{s} \approx 2.08\ \mathrm{ms}.
```

The UI exposes `dt` directly rather than a generic speed multiplier. Smaller values are more stable for stiff contact forces but require more simulation steps to cover the same physical time. Visual snapshots are sent to the UI at most about 30 times per second, so rendering does not force the simulation to publish every physics step.

## Interaction model

The current prototype uses a simplified pair interaction controlled from the UI. `Pair force` is enabled by default. For particles `i` and `j`, the signed surface gap is

```math
h = |\mathbf{r}_{ji}| - (R_i + R_j),
```

where `h > 0` means separated particle surfaces, `h = 0` means exact contact, and `h < 0` means numerical overlap. The vector `r_ji` is evaluated with periodic minimum-image wrapping.

For positive gaps, the attractive regularized branch is

```math
F_a(h) = -\frac{A h^2}{h^3 + \ell^3}, \quad h \ge 0.
```

This removes the singularity at contact while preserving the far-field `1 / h` behavior for `h >> ell`.

For overlaps, the repulsive contact branch is selected in the UI:

```math
F_c(h) =
\begin{cases}
K(-h)^2, & \text{Quadratic},\\
K(-h), & \text{Linear},\\
K(-h)^{3/2}, & \text{Hertz},
\end{cases}
\quad h < 0.
```

The default contact stiffness scale follows

```math
K = \frac{A}{\ell^3}.
```

Normal pair damping is added along the particle-pair normal:

```math
F_n = F_a + F_c - \gamma ((\mathbf{v}_j - \mathbf{v}_i) \cdot \mathbf{n}).
```

The force is applied along `n = r_ji / |r_ji|`. In addition to the force model, the optional overlap-correction solver geometrically reduces remaining overlaps after integration. This correction changes positions only; it does not change velocities.

The UI stability label is a heuristic based on the current integration step, the smallest visible radius, `A`, and `ell`. It is meant as a warning for obviously too-large steps, not as a formal proof of numerical stability.

## Impulse collisions

`Impulse collisions` is independent of the force-based contact model and overlap correction. After each integration substep, overlapping particle pairs with approaching normal velocity receive a normal velocity impulse:

```math
J = -\frac{(1 + e)\,(\mathbf{v}_j - \mathbf{v}_i)\cdot\mathbf{n}}{m_i^{-1} + m_j^{-1}},
```

where `e` is the restitution coefficient from the UI. `e = 1` gives an elastic bounce, while `e = 0` removes the approaching normal component without bounce. The impulse update is

```math
\Delta\mathbf{v}_i = -J\,m_i^{-1}\mathbf{n}, \qquad
\Delta\mathbf{v}_j =  J\,m_j^{-1}\mathbf{n}.
```

This solver changes velocities only. If visible overlaps should also be reduced, enable `Overlap correction` separately.

## Additional forces

`Damping` applies a simple global velocity-proportional drag to each particle:

```math
\mathbf{F}_d = -c\,\mathbf{v}.
```

It removes kinetic energy from the system and is useful for suppressing long oscillations while tuning attractive and contact forces. This is separate from `Pair damping`, which acts only along the normal direction of interacting particle pairs.

`Constant field` applies the same acceleration to all particles:

```math
\mathbf{F}_g = m\,\mathbf{a}_0.
```

In the current prototype the default acceleration points in the negative `y` direction. It is a debugging and demonstration force, similar to a uniform gravity-like field, and can be toggled independently of pair interactions.

## Build

```sh
cmake -S . -B build
cmake --build build --target main.out
```

The simulation core uses `float` by default. For a double-precision debug build:

```sh
cmake -S . -B build -DPARTICLE_REAL_TYPE=double
cmake --build build --target main.out
```

Valid values are `float` and `double`.

Multithreaded simulation loops are enabled by default. To disable them:

```sh
cmake -S . -B build -DPARTICLE_ENABLE_PARALLEL=OFF
cmake --build build --target main.out
```

The default split threshold is `256` items. It can be changed with:

```sh
cmake -S . -B build -DPARTICLE_PARALLEL_MIN_ITEMS=4096
```

The executable is written to the build directory as `build/main.out`.

## Run

```sh
./build/main.out
```

For browser/server mode:

```sh
./build/main.out --server
```

The server mode uses port `8080`.
